<?php
// api/mark_read.php — mark all notifications read for current user
session_start();
require_once '../includes/db.php';
$uid  = (int)($_SESSION['user_id'] ?? 0);
$role = $_SESSION['user_role'] ?? '';
if ($uid && $role) {
    $conn->query("UPDATE notifications SET is_read=1 WHERE user_type='$role' AND user_id=$uid");
}
http_response_code(200);
