<?php
session_start(); require_once 'includes/db.php';
if (!empty($_SESSION['user_id'])) { header('Location: '.($_SESSION['user_role']==='student'?'student/dashboard.php':'faculty/dashboard.php')); exit; }
$error=''; $tab='student';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $tab=trim($_POST['login_type']??'student'); $code=trim($_POST['user_code']??''); $pw=$_POST['password']??'';
    if (!$code||!$pw) { $error='Please enter your ID and password.'; }
    else {
        $tbl = $tab==='student' ? ['students','student_id','student_code'] : ['faculty','faculty_id','faculty_code'];
        $stmt=$conn->prepare("SELECT {$tbl[1]}, full_name, password FROM {$tbl[0]} WHERE {$tbl[2]}=?");
        $stmt->bind_param('s',$code); $stmt->execute(); $u=$stmt->get_result()->fetch_assoc(); $stmt->close();
        if ($u && password_verify($pw,$u['password'])) {
            $_SESSION['user_id']=$u[$tbl[1]]; $_SESSION['user_name']=$u['full_name'];
            $_SESSION['user_code']=$code; $_SESSION['user_role']=$tab;
            header('Location: '.$tab.'/dashboard.php'); exit;
        } else { $error='Invalid '.ucfirst($tab).' ID or password.'; }
    }
}
if (isset($_GET['error'])) $error=$_GET['error']==='session'?'Session expired. Please log in again.':'Access denied.';
?>
<!DOCTYPE html><html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Login — Course Enrollment Simulator</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="login-page">
  <!-- Left branding panel -->
  <div class="login-left">
    <div class="login-brand">
      <div class="login-brand-icon">&#127891;</div>
      <h1>Course Enrollment<br>Simulator</h1>
      <p>University Academic Portal</p>
      <span class="login-brand-type" id="brandType"><?= $tab==='faculty'?'Faculty Login':'Student Login' ?></span>
    </div>
  </div>

  <!-- Right form -->
  <div class="login-right">
    <div class="login-box">
      <div class="login-box-title">Welcome back</div>
      <div class="login-box-sub">Sign in to continue to your portal.</div>

      <div class="login-role-tabs">
        <button class="login-role-tab <?= $tab==='student'?'active':'' ?>" onclick="setTab('student')">Student Login</button>
        <button class="login-role-tab <?= $tab==='faculty'?'active':'' ?>" onclick="setTab('faculty')">Faculty Login</button>
      </div>

      <?php if ($error): ?><div class="login-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

      <form method="POST">
        <input type="hidden" name="login_type" id="loginType" value="<?= htmlspecialchars($tab) ?>">
        <div class="form-group">
          <label class="form-label" id="idLabel"><?= $tab==='faculty'?'Faculty ID':'Student ID' ?></label>
          <input type="text" name="user_code" id="codeInput" class="form-control"
            placeholder="<?= $tab==='faculty'?'e.g. FAC-001':'e.g. STU-2024-001' ?>"
            value="<?= htmlspecialchars($_POST['user_code']??'') ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
        </div>
        <button type="submit" class="login-btn">Login</button>
      </form>

      <div class="login-hint">
        <div class="login-hint-title">Sample Credentials</div>
        <div class="login-hint-grid">
          <div><div class="lh-id">STU-2024-001</div><div class="lh-pass">student123</div></div>
          <div><div class="lh-id">FAC-001</div><div class="lh-pass">faculty123</div></div>
        </div>
      </div>
      <p style="text-align:center;margin-top:12px;font-size:12px;color:var(--text-3);">
        First time? <a href="setup.php" style="color:var(--brown-500);font-weight:600;text-decoration:none;">Run setup</a>
      </p>
    </div>
  </div>
</div>
<script>
const m={student:{label:'Student ID',ph:'e.g. STU-2024-001',brand:'Student Login'},faculty:{label:'Faculty ID',ph:'e.g. FAC-001',brand:'Faculty Login'}};
function setTab(t){
  document.getElementById('loginType').value=t;
  document.getElementById('idLabel').textContent=m[t].label;
  document.getElementById('codeInput').placeholder=m[t].ph;
  document.getElementById('brandType').textContent=m[t].brand;
  document.querySelectorAll('.login-role-tab').forEach((b,i)=>b.classList.toggle('active',(i===0&&t==='student')||(i===1&&t==='faculty')));
}
</script>
</body></html>
