<?php
// ============================================================
// setup.php — Run this ONCE to initialize the database
// Access via: http://localhost/course_enrollment/setup.php
// ============================================================

$host   = 'localhost';
$user   = 'root';
$pass   = '';  // Change if your MySQL root has a password
$dbname = 'course_enrollment_db';

$conn = new mysqli($host, $user, $pass);
if ($conn->connect_error) {
    die("<p style='color:red;font-family:sans-serif'>Connection failed: " . $conn->connect_error . "</p>");
}

$sql_file = file_get_contents(__DIR__ . '/sql/setup.sql');
$queries = array_filter(array_map('trim', explode(';', $sql_file)));

$log = [];
foreach ($queries as $q) {
    if (!empty($q)) {
        if ($conn->query($q) === TRUE) {
            $log[] = ['ok', substr($q, 0, 60) . '...'];
        } else {
            $log[] = ['err', "Error: " . $conn->error . " | Query: " . substr($q, 0, 80)];
        }
    }
}

$conn->select_db($dbname);

// ─── SEED DATA ──────────────────────────────────────────────

// Passwords
$passStu1    = password_hash('student123', PASSWORD_DEFAULT);
$passStu2    = password_hash('student456', PASSWORD_DEFAULT);
$passFac1    = password_hash('faculty123', PASSWORD_DEFAULT);
$passFac2    = password_hash('faculty456', PASSWORD_DEFAULT);

// Students
$conn->query("INSERT IGNORE INTO students (student_code, full_name, password, year_level, program) VALUES
('STU-2024-001', 'Maria Santos',  '$passStu1', 2, 'BS Computer Science'),
('STU-2024-002', 'Juan Dela Cruz', '$passStu2', 1, 'BS Information Technology')");

// Faculty
$conn->query("INSERT IGNORE INTO faculty (faculty_code, full_name, password, department) VALUES
('FAC-001', 'Prof. Ana Reyes',   '$passFac1', 'Computer Science'),
('FAC-002', 'Prof. Ben Torres',  '$passFac2', 'Information Technology')");

// Active semester — dates set around now so add/drop is OPEN
$today        = date('Y-m-d');
$twoWeeksAgo  = date('Y-m-d', strtotime('-14 days'));
$twoWeeksAhead = date('Y-m-d', strtotime('+14 days'));
$oneMonthAhead = date('Y-m-d', strtotime('+30 days'));
$fourMonthsAhead = date('Y-m-d', strtotime('+120 days'));

$conn->query("INSERT IGNORE INTO semesters
  (semester_name, school_year, start_date, end_date,
   enrollment_start, enrollment_end, add_drop_start, add_drop_end, is_active)
  VALUES
  ('1st Semester', '2024-2025',
   '$today', '$fourMonthsAhead',
   '$twoWeeksAgo', '$twoWeeksAhead',
   '$today', '$twoWeeksAhead', 1)");

$sem = $conn->query("SELECT semester_id FROM semesters WHERE is_active=1 LIMIT 1")->fetch_assoc();
$sid = $sem['semester_id'];

$f1 = $conn->query("SELECT faculty_id FROM faculty WHERE faculty_code='FAC-001'")->fetch_assoc();
$f2 = $conn->query("SELECT faculty_id FROM faculty WHERE faculty_code='FAC-002'")->fetch_assoc();
$f1id = $f1['faculty_id'];
$f2id = $f2['faculty_id'];

// Courses — some are past-semester prerequisites (no semester = completed)
$conn->query("INSERT IGNORE INTO courses (course_code, course_title, units, capacity, semester_id, faculty_id, description) VALUES
('CS101',  'Introduction to Computing',       3, 40, NULL, $f1id, 'Fundamentals of computing and IT concepts.'),
('CS102',  'Programming 1',                   3, 35, NULL, $f1id, 'Introduction to programming using Python.'),
('CS103',  'Programming 2',                   3, 30, $sid, $f1id, 'Intermediate programming using Java.'),
('CS201',  'Data Structures',                 3, 25, $sid, $f1id, 'Arrays, linked lists, trees, and graphs.'),
('CS202',  'Discrete Mathematics',            3, 30, $sid, $f2id, 'Logic, sets, relations, and combinatorics.'),
('CS203',  'Object-Oriented Programming',     3, 25, $sid, $f1id, 'OOP principles using Java and UML design.'),
('IT101',  'Web Development Fundamentals',    3, 30, $sid, $f2id, 'HTML, CSS, and introductory JavaScript.'),
('IT201',  'Database Management Systems',     3, 25, $sid, $f2id, 'Relational DB design and SQL.'),
('IT202',  'Systems Analysis & Design',       3, 25, $sid, $f2id, 'SDLC, UML diagrams, system modeling.'),
('MATH101','Calculus 1',                       3, 40, NULL, $f2id, 'Limits, derivatives, and integrals.'),
('MATH201','Calculus 2',                       3, 35, $sid, $f2id, 'Advanced integration and series.')");

// Prerequisites
$getID = fn($code) => $conn->query("SELECT course_id FROM courses WHERE course_code='$code'")->fetch_assoc()['course_id'];
$cs101=$getID('CS101'); $cs102=$getID('CS102'); $cs103=$getID('CS103');
$cs201=$getID('CS201'); $cs203=$getID('CS203'); $it201=$getID('IT201');
$math101=$getID('MATH101'); $math201=$getID('MATH201');

$conn->query("INSERT IGNORE INTO prerequisites (course_id, required_course_id) VALUES
($cs103, $cs102),
($cs201, $cs103),
($cs203, $cs103),
($it201, $cs101),
($math201, $math101)");

// Sample enrollments for Student 1
$s1 = $conn->query("SELECT student_id FROM students WHERE student_code='STU-2024-001'")->fetch_assoc();
$s2 = $conn->query("SELECT student_id FROM students WHERE student_code='STU-2024-002'")->fetch_assoc();
$s1id = $s1['student_id']; $s2id = $s2['student_id'];

// Student 1 has completed CS101, CS102 (past semester — confirmed/graded)
$conn->query("INSERT IGNORE INTO semesters (semester_name, school_year, start_date, end_date, is_active) VALUES
  ('2nd Semester', '2023-2024', '2024-01-01', '2024-05-31', 0)");
$pastSem = $conn->query("SELECT semester_id FROM semesters WHERE is_active=0 LIMIT 1")->fetch_assoc();
$psid = $pastSem['semester_id'];

$conn->query("INSERT IGNORE INTO enrollments (student_id, course_id, semester_id, status) VALUES
  ($s1id, $cs101, $psid, 'confirmed'),
  ($s1id, $cs102, $psid, 'confirmed')");

// Grade for CS101 and CS102 (student 1 passed)
foreach([$cs101, $cs102] as $cid) {
    $enr = $conn->query("SELECT enrollment_id FROM enrollments WHERE student_id=$s1id AND course_id=$cid LIMIT 1")->fetch_assoc();
    if ($enr) {
        $eid = $enr['enrollment_id'];
        $conn->query("INSERT IGNORE INTO grades (enrollment_id, grade, remarks, submitted_by) VALUES ($eid, 1.50, 'Passed', $f1id)");
    }
}

// Student 1 enrolled in current semester
$conn->query("INSERT IGNORE INTO enrollments (student_id, course_id, semester_id, status) VALUES
  ($s1id, $cs103, $sid, 'approved'),
  ($s1id, $cs203, $sid, 'pending')");

// Student 2 has a pending enrollment
$conn->query("INSERT IGNORE INTO enrollments (student_id, course_id, semester_id, status) VALUES
  ($s2id, $cs201, $sid, 'pending')");

// Notifications
$conn->query("INSERT IGNORE INTO notifications (user_type, user_id, message) VALUES
  ('student', $s1id, 'Your enrollment in CS203 is pending faculty review.'),
  ('student', $s1id, 'Your enrollment in CS103 has been approved!')");

$log[] = ['ok', 'Sample data inserted successfully.'];
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Setup — Course Enrollment Simulator</title>
<style>
  body { font-family: 'Segoe UI', sans-serif; background: #f0f4f8; margin: 0; padding: 40px; }
  .box { max-width: 700px; margin: auto; background: white; border-radius: 12px; padding: 32px; box-shadow: 0 4px 20px rgba(0,0,0,.08); }
  h1 { color: #1e3a5f; margin-top: 0; }
  .ok  { color: #16a34a; }
  .err { color: #dc2626; }
  ul { list-style: none; padding: 0; }
  li { padding: 6px 0; font-size: 14px; border-bottom: 1px solid #f0f0f0; }
  .btn { display: inline-block; margin-top: 20px; padding: 12px 28px; background: #1e3a5f; color: white; border-radius: 8px; text-decoration: none; font-weight: 600; }
  .creds { background: #f0f9f0; border: 1px solid #86efac; border-radius: 8px; padding: 16px; margin-top: 20px; }
  .creds h3 { margin-top: 0; color: #166534; }
  table { width: 100%; border-collapse: collapse; font-size: 14px; }
  td, th { padding: 8px 12px; border-bottom: 1px solid #e2e8f0; text-align: left; }
  th { background: #f8fafc; color: #64748b; font-weight: 600; }
</style>
</head>
<body>
<div class="box">
  <h1>🎓 Course Enrollment Simulator — Setup</h1>
  <ul>
    <?php foreach($log as [$type, $msg]): ?>
      <li class="<?= $type ?>"><?= $type === 'ok' ? '✔' : '✖' ?> <?= htmlspecialchars($msg) ?></li>
    <?php endforeach; ?>
  </ul>
  <div class="creds">
    <h3>✅ Setup Complete! Sample Login Credentials</h3>
    <table>
      <tr><th>Role</th><th>ID / Code</th><th>Password</th></tr>
      <tr><td>Student 1</td><td>STU-2024-001</td><td>student123</td></tr>
      <tr><td>Student 2</td><td>STU-2024-002</td><td>student456</td></tr>
      <tr><td>Faculty 1</td><td>FAC-001</td><td>faculty123</td></tr>
      <tr><td>Faculty 2</td><td>FAC-002</td><td>faculty456</td></tr>
    </table>
    <p style="margin-bottom:0;font-size:13px;color:#666;">⚠️ Delete or restrict access to setup.php after use.</p>
  </div>
  <a class="btn" href="index.php">→ Go to Login</a>
</div>
</body>
</html>
