-- ============================================================
-- Course Enrollment Simulator — Database Setup
-- Run via setup.php or import in phpMyAdmin
-- ============================================================

CREATE DATABASE IF NOT EXISTS course_enrollment_db;
USE course_enrollment_db;

-- ─────────────────────────────────────────────
-- TABLES
-- ─────────────────────────────────────────────

DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS add_drop_requests;
DROP TABLE IF EXISTS grades;
DROP TABLE IF EXISTS enrollments;
DROP TABLE IF EXISTS prerequisites;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS semesters;
DROP TABLE IF EXISTS faculty;
DROP TABLE IF EXISTS students;

CREATE TABLE students (
  student_id   INT AUTO_INCREMENT PRIMARY KEY,
  student_code VARCHAR(20)  NOT NULL UNIQUE,
  full_name    VARCHAR(100) NOT NULL,
  password     VARCHAR(255) NOT NULL,
  year_level   INT          DEFAULT 1,
  program      VARCHAR(100) DEFAULT 'BS Computer Science',
  created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE faculty (
  faculty_id   INT AUTO_INCREMENT PRIMARY KEY,
  faculty_code VARCHAR(20)  NOT NULL UNIQUE,
  full_name    VARCHAR(100) NOT NULL,
  password     VARCHAR(255) NOT NULL,
  department   VARCHAR(100) DEFAULT 'Computer Science',
  created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE semesters (
  semester_id       INT AUTO_INCREMENT PRIMARY KEY,
  semester_name     VARCHAR(80) NOT NULL,
  school_year       VARCHAR(20) NOT NULL,
  start_date        DATE,
  end_date          DATE,
  enrollment_start  DATE,
  enrollment_end    DATE,
  add_drop_start    DATE,
  add_drop_end      DATE,
  is_active         TINYINT(1) DEFAULT 0
);

CREATE TABLE courses (
  course_id    INT AUTO_INCREMENT PRIMARY KEY,
  course_code  VARCHAR(20)  NOT NULL UNIQUE,
  course_title VARCHAR(120) NOT NULL,
  units        INT          DEFAULT 3,
  capacity     INT          DEFAULT 30,
  semester_id  INT,
  faculty_id   INT,
  description  TEXT,
  FOREIGN KEY (semester_id) REFERENCES semesters(semester_id),
  FOREIGN KEY (faculty_id)  REFERENCES faculty(faculty_id)
);

CREATE TABLE prerequisites (
  prereq_id          INT AUTO_INCREMENT PRIMARY KEY,
  course_id          INT NOT NULL,
  required_course_id INT NOT NULL,
  FOREIGN KEY (course_id)          REFERENCES courses(course_id),
  FOREIGN KEY (required_course_id) REFERENCES courses(course_id)
);

CREATE TABLE enrollments (
  enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
  student_id    INT NOT NULL,
  course_id     INT NOT NULL,
  semester_id   INT NOT NULL,
  status        ENUM('pending','verified','approved','confirmed','dropped','rejected') DEFAULT 'pending',
  enrolled_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_enrollment (student_id, course_id, semester_id),
  FOREIGN KEY (student_id)  REFERENCES students(student_id),
  FOREIGN KEY (course_id)   REFERENCES courses(course_id),
  FOREIGN KEY (semester_id) REFERENCES semesters(semester_id)
);

CREATE TABLE grades (
  grade_id      INT AUTO_INCREMENT PRIMARY KEY,
  enrollment_id INT NOT NULL UNIQUE,
  grade         DECIMAL(4,2),
  remarks       VARCHAR(50),
  submitted_by  INT,
  submitted_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (enrollment_id) REFERENCES enrollments(enrollment_id),
  FOREIGN KEY (submitted_by)  REFERENCES faculty(faculty_id)
);

CREATE TABLE add_drop_requests (
  request_id   INT AUTO_INCREMENT PRIMARY KEY,
  student_id   INT NOT NULL,
  course_id    INT NOT NULL,
  request_type ENUM('add','drop') NOT NULL,
  status       ENUM('pending','approved','rejected') DEFAULT 'pending',
  reason       TEXT,
  requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  processed_at TIMESTAMP NULL,
  processed_by INT NULL,
  FOREIGN KEY (student_id)  REFERENCES students(student_id),
  FOREIGN KEY (course_id)   REFERENCES courses(course_id),
  FOREIGN KEY (processed_by) REFERENCES faculty(faculty_id)
);

CREATE TABLE notifications (
  notif_id   INT AUTO_INCREMENT PRIMARY KEY,
  user_type  ENUM('student','faculty') NOT NULL,
  user_id    INT NOT NULL,
  message    TEXT NOT NULL,
  is_read    TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP  DEFAULT CURRENT_TIMESTAMP
);
