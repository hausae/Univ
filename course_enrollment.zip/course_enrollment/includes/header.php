<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

$unread    = unread_count($conn);
$role      = $_SESSION['user_role'] ?? '';
$username  = $_SESSION['user_name'] ?? 'User';
$user_code = $_SESSION['user_code'] ?? '';
$rp        = defined('IN_SUBFOLDER') ? '../' : './';
$np        = defined('IN_SUBFOLDER') ? '../'.$role.'/' : $role.'/';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($page_title ?? 'Enrollment') ?> — Course Enrollment Simulator</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= $rp ?>assets/css/style.css">
</head>
<body>
<aside class="sidebar">
  <div class="sidebar-brand">
    <span class="sidebar-brand-name">Course Enrollment Simulator</span>
    <span class="sidebar-portal-tag"><?= ucfirst($role) ?> Portal</span>
  </div>

  <nav class="sidebar-nav">
    <?php if ($role === 'student'): ?>
      <a href="<?= $np ?>dashboard.php"         class="nav-item <?= $active_nav==='dashboard'?'active':'' ?>"><span class="nav-icon">&#9632;</span> Dashboard</a>
      <a href="<?= $np ?>grades.php"            class="nav-item <?= $active_nav==='grades'   ?'active':'' ?>"><span class="nav-icon">&#9632;</span> View Grades</a>
      <a href="<?= $np ?>subjects.php"          class="nav-item <?= $active_nav==='subjects' ?'active':'' ?>"><span class="nav-icon">&#9632;</span> View Subjects</a>
      <a href="<?= $np ?>add_subject.php"       class="nav-item <?= $active_nav==='add_sub'  ?'active':'' ?>"><span class="nav-icon">&#9632;</span> Add Subject</a>
      <a href="<?= $np ?>drop_subject.php"      class="nav-item <?= $active_nav==='drop_sub' ?'active':'' ?>"><span class="nav-icon">&#9632;</span> Drop Subject</a>
      <a href="<?= $np ?>enrollment.php"        class="nav-item <?= $active_nav==='enroll'   ?'active':'' ?>"><span class="nav-icon">&#9632;</span> Enrollment</a>
    <?php else:
      $pe = (int)$conn->query("SELECT COUNT(*) c FROM enrollments WHERE status='pending'")->fetch_assoc()['c'];
      $pa = (int)$conn->query("SELECT COUNT(*) c FROM add_drop_requests WHERE status='pending'")->fetch_assoc()['c'];
    ?>
      <a href="<?= $np ?>dashboard.php"         class="nav-item <?= $active_nav==='dashboard' ?'active':'' ?>"><span class="nav-icon">&#9632;</span> Dashboard</a>
      <a href="<?= $np ?>enrollments.php"       class="nav-item <?= $active_nav==='enrollments'?'active':'' ?>"><span class="nav-icon">&#9632;</span> View Enrollments<?php if($pe>0): ?><span class="badge"><?= $pe ?></span><?php endif; ?></a>
      <a href="<?= $np ?>verify.php"            class="nav-item <?= $active_nav==='verify'    ?'active':'' ?>"><span class="nav-icon">&#9632;</span> Verify Enrollment</a>
      <a href="<?= $np ?>approve_addrop.php"    class="nav-item <?= $active_nav==='addrop'    ?'active':'' ?>"><span class="nav-icon">&#9632;</span> Approve Add/Drop<?php if($pa>0): ?><span class="badge"><?= $pa ?></span><?php endif; ?></a>
      <a href="<?= $np ?>submit_grades.php"     class="nav-item <?= $active_nav==='submit_gr' ?'active':'' ?>"><span class="nav-icon">&#9632;</span> Submit Grades</a>
      <a href="<?= $np ?>view_grades.php"       class="nav-item <?= $active_nav==='view_gr'   ?'active':'' ?>"><span class="nav-icon">&#9632;</span> View Grades</a>
    <?php endif; ?>
    <a href="<?= $rp ?>logout.php" class="nav-item"><span class="nav-icon">&#9632;</span> Logout</a>
  </nav>

  <div class="sidebar-footer">
    <div class="sidebar-user">
      <span class="sidebar-user-name"><?= htmlspecialchars($username) ?></span>
      <span class="sidebar-user-id"><?= htmlspecialchars($user_code) ?></span>
    </div>
  </div>
</aside>

<main class="main-content">
  <header class="topbar">
    <span class="topbar-title"><?= htmlspecialchars($page_title ?? '') ?></span>
    <div class="topbar-right">
      <?php $sem = active_semester($conn); if ($sem): ?>
      <div class="sem-tag"><?= htmlspecialchars($sem['semester_name']) ?>, AY <?= htmlspecialchars($sem['school_year']) ?></div>
      <?php endif; ?>
      <div class="notif-btn" onclick="toggleNotifs()" title="Notifications">
        &#9993;<?php if ($unread > 0): ?><span class="badge"><?= $unread ?></span><?php endif; ?>
      </div>
    </div>
  </header>

  <?php
  $s = get_flash('success'); $e = get_flash('error'); $i = get_flash('info');
  if ($s): ?><div class="alert alert-success"><?= htmlspecialchars($s) ?></div><?php endif;
  if ($e): ?><div class="alert alert-error"><?= htmlspecialchars($e) ?></div><?php endif;
  if ($i): ?><div class="alert alert-info"><?= htmlspecialchars($i) ?></div><?php endif;
  ?>
  <div class="content-body">
