<?php
// includes/auth.php — Session & authentication helpers

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ── Require login; redirect if not authenticated ──────────────
function require_login(string $role = '') {
    if (empty($_SESSION['user_id'])) {
        header('Location: ' . base_url() . 'index.php?error=session');
        exit;
    }
    if ($role && $_SESSION['user_role'] !== $role) {
        header('Location: ' . base_url() . 'index.php?error=access');
        exit;
    }
}

// ── Return base URL (works for subfolders) ────────────────────
function base_url(): string {
    $script = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
    // Walk up to project root
    $depth = substr_count(str_replace(dirname($_SERVER['DOCUMENT_ROOT']), '', realpath(__DIR__ . '/..')), DIRECTORY_SEPARATOR);
    $parts = explode('/', trim($script, '/'));
    $root  = '/' . implode('/', array_slice($parts, 0, count($parts) - (defined('IN_SUBFOLDER') ? 1 : 0)));
    return rtrim($root, '/') . '/';
}

// ── Add a notification ────────────────────────────────────────
function add_notification($conn, string $type, int $uid, string $msg) {
    $stmt = $conn->prepare("INSERT INTO notifications (user_type, user_id, message) VALUES (?,?,?)");
    $stmt->bind_param('sis', $type, $uid, $msg);
    $stmt->execute();
    $stmt->close();
}

// ── Count unread notifications for current user ───────────────
function unread_count($conn): int {
    if (empty($_SESSION['user_id'])) return 0;
    $role = $_SESSION['user_role'];
    $uid  = $_SESSION['user_id'];
    $r = $conn->query("SELECT COUNT(*) AS c FROM notifications WHERE user_type='$role' AND user_id=$uid AND is_read=0");
    return (int)$r->fetch_assoc()['c'];
}

// ── Is enrollment period open? ────────────────────────────────
function enrollment_open($conn): bool {
    $today = date('Y-m-d');
    $r = $conn->query("SELECT 1 FROM semesters WHERE is_active=1
        AND enrollment_start <= '$today' AND enrollment_end >= '$today' LIMIT 1");
    return $r && $r->num_rows > 0;
}

// ── Is add/drop period open? ──────────────────────────────────
function add_drop_open($conn): bool {
    $today = date('Y-m-d');
    $r = $conn->query("SELECT 1 FROM semesters WHERE is_active=1
        AND add_drop_start <= '$today' AND add_drop_end >= '$today' LIMIT 1");
    return $r && $r->num_rows > 0;
}

// ── Get active semester ───────────────────────────────────────
function active_semester($conn): ?array {
    $r = $conn->query("SELECT * FROM semesters WHERE is_active=1 LIMIT 1");
    return $r ? $r->fetch_assoc() : null;
}

// ── Check if student passed a required course ─────────────────
function student_passed($conn, int $student_id, int $course_id): bool {
    $r = $conn->query("SELECT e.enrollment_id FROM enrollments e
        JOIN grades g ON g.enrollment_id = e.enrollment_id
        WHERE e.student_id = $student_id AND e.course_id = $course_id
          AND e.status IN ('confirmed','approved') AND g.grade IS NOT NULL
        LIMIT 1");
    return $r && $r->num_rows > 0;
}

// ── Check prerequisites for a course ─────────────────────────
// Returns array of ['met'=>bool, 'prereqs'=>[...]]
function check_prerequisites($conn, int $course_id, int $student_id): array {
    $r = $conn->query("SELECT p.required_course_id, c.course_code, c.course_title
        FROM prerequisites p
        JOIN courses c ON c.course_id = p.required_course_id
        WHERE p.course_id = $course_id");
    if (!$r || $r->num_rows === 0) {
        return ['met' => true, 'prereqs' => []];
    }
    $prereqs = [];
    $all_met = true;
    while ($row = $r->fetch_assoc()) {
        $met = student_passed($conn, $student_id, (int)$row['required_course_id']);
        if (!$met) $all_met = false;
        $prereqs[] = array_merge($row, ['passed' => $met]);
    }
    return ['met' => $all_met, 'prereqs' => $prereqs];
}

// ── Current enrolled count for a course ──────────────────────
function enrolled_count($conn, int $course_id, int $semester_id): int {
    $r = $conn->query("SELECT COUNT(*) AS c FROM enrollments
        WHERE course_id=$course_id AND semester_id=$semester_id
          AND status NOT IN ('dropped','rejected')");
    return (int)$r->fetch_assoc()['c'];
}

// ── Flash message helpers ─────────────────────────────────────
function flash(string $key, string $msg) {
    $_SESSION['flash'][$key] = $msg;
}
function get_flash(string $key): string {
    $msg = $_SESSION['flash'][$key] ?? '';
    unset($_SESSION['flash'][$key]);
    return $msg;
}
