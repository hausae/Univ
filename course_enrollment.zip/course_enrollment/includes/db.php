<?php
// includes/db.php — Database connection
// Adjust host/user/pass if needed for your XAMPP setup

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');          // Change if your MySQL root has a password
define('DB_NAME', 'course_enrollment_db');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("
    <div style='font-family:sans-serif;padding:40px;'>
      <h2 style='color:#dc2626'>Database Connection Failed</h2>
      <p>" . $conn->connect_error . "</p>
      <p>Make sure XAMPP MySQL is running, then
         <a href='../setup.php'>run setup.php</a> first.</p>
    </div>");
}

$conn->set_charset('utf8mb4');
