  </div>
</main>

<div id="notif-panel" class="notif-panel hidden">
  <div class="notif-header">
    <span>Notifications</span>
    <button onclick="markAllRead()">Mark all read</button>
  </div>
  <div class="notif-list">
    <?php
    $uid=$_SESSION['user_id']??0; $rl=$_SESSION['user_role']??'student';
    $ns=$conn->query("SELECT * FROM notifications WHERE user_type='$rl' AND user_id=$uid ORDER BY created_at DESC LIMIT 12");
    if($ns&&$ns->num_rows>0): while($n=$ns->fetch_assoc()):
    ?><div class="notif-item <?= $n['is_read']?'':'unread' ?>"><p><?= htmlspecialchars($n['message']) ?></p><small><?= date('M d, Y g:ia',strtotime($n['created_at'])) ?></small></div>
    <?php endwhile; else: ?><div class="notif-empty">No notifications.</div><?php endif; ?>
  </div>
</div>
<div id="notif-overlay" class="notif-overlay hidden" onclick="toggleNotifs()"></div>

<script>
function toggleNotifs(){document.getElementById('notif-panel').classList.toggle('hidden');document.getElementById('notif-overlay').classList.toggle('hidden');}
function markAllRead(){fetch('<?= defined('IN_SUBFOLDER')?'../':'' ?>api/mark_read.php').then(()=>{document.querySelectorAll('.notif-item.unread').forEach(el=>el.classList.remove('unread'));document.querySelectorAll('.notif-btn .badge').forEach(el=>el.remove());});}
document.querySelectorAll('.alert').forEach(el=>{setTimeout(()=>el.style.opacity='0',3800);setTimeout(()=>el.remove(),4200);});
</script>
</body></html>
