<?php
session_start();
session_destroy();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Logged Out — Course Enrollment Simulator</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="logout-screen">
  <div class="logout-box">
    <div class="logout-check">&#10003;</div>
    <h2>You have been logged out.</h2>
    <p>Thank you for using the Course Enrollment Simulator.</p>
    <a href="index.php" class="btn btn-brown btn-block" style="font-size:14px;padding:10px;">Back to Login</a>
  </div>
</div>
</body>
</html>
