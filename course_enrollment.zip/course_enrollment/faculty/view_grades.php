<?php
define('IN_SUBFOLDER',true); session_start();
require_once '../includes/db.php'; require_once '../includes/auth.php';
require_login('faculty');
$fid=$_SESSION['user_id']; $sem=active_semester($conn);

$filter_cid=(int)($_GET['course_id']??0);
$filter_sem_id=(int)($_GET['semester_id']??($sem?$sem['semester_id']:0));

// My courses across all semesters
$my_courses=[];
$r=$conn->query("SELECT c.course_id,c.course_code,c.course_title,s.semester_id,s.semester_name,s.school_year FROM courses c JOIN semesters s ON s.semester_id=c.semester_id WHERE c.faculty_id=$fid ORDER BY s.start_date DESC,c.course_code");
while($row=$r->fetch_assoc()) $my_courses[]=$row;
if(!$filter_cid && !empty($my_courses)) $filter_cid=$my_courses[0]['course_id'];
if(!$filter_sem_id && !empty($my_courses)) $filter_sem_id=$my_courses[0]['semester_id'];

$rows=[];
if($filter_cid){
    $r=$conn->query("SELECT s2.student_code,s2.full_name AS sname,g.grade,g.remarks,e.status FROM grades g JOIN enrollments e ON e.enrollment_id=g.enrollment_id JOIN students s2 ON s2.student_id=e.student_id JOIN courses c ON c.course_id=e.course_id WHERE c.course_id=$filter_cid AND e.semester_id=$filter_sem_id ORDER BY s2.full_name");
    while($row=$r->fetch_assoc()) $rows[]=$row;
}
$page_title='View Grades'; $active_nav='view_gr';
include '../includes/header.php';
?>

<!-- Filters matching wireframe -->
<div class="flex-center gap-3 mb-4" style="flex-wrap:wrap;">
  <div class="flex-center gap-2">
    <label style="font-size:12px;color:var(--text-3);">Subject:</label>
    <select class="form-control" style="width:auto;" onchange="location='?course_id='+this.value+'&semester_id=<?= $filter_sem_id ?>'">
      <?php foreach($my_courses as $c): ?>
      <option value="<?= $c['course_id'] ?>" <?= $filter_cid==$c['course_id']?'selected':'' ?>><?= htmlspecialchars($c['course_code'].' — '.$c['course_title']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="flex-center gap-2">
    <label style="font-size:12px;color:var(--text-3);">Semester:</label>
    <select class="form-control" style="width:auto;" onchange="location='?course_id=<?= $filter_cid ?>&semester_id='+this.value">
      <?php
      $all_sems=$conn->query("SELECT * FROM semesters ORDER BY start_date DESC");
      while($s=$all_sems->fetch_assoc()):
      ?><option value="<?= $s['semester_id'] ?>" <?= $filter_sem_id==$s['semester_id']?'selected':'' ?>><?= htmlspecialchars($s['semester_name'].', AY '.$s['school_year']) ?></option>
      <?php endwhile; ?>
    </select>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <span class="card-title">Grade List</span>
    <a href="submit_grades.php?course_id=<?= $filter_cid ?>" class="btn btn-brown btn-sm">Update Grades</a>
  </div>
  <?php if(empty($rows)): ?>
  <div class="card-body"><div class="empty-state"><p>No grades submitted for this subject yet.</p></div></div>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>Student ID</th><th>Student Name</th><th>Grade</th></tr></thead>
    <tbody><?php foreach($rows as $r):
      $gv=$r['grade']!==null?(float)$r['grade']:null;
      $gcls=$gv!==null?($gv<=3.0?'pass':'fail'):'';
    ?>
    <tr>
      <td class="td-code"><?= htmlspecialchars($r['student_code']) ?></td>
      <td><?= htmlspecialchars($r['sname']) ?></td>
      <td>
        <?php if($r['remarks']==='INC'): ?><span class="grade-val inc">INC</span>
        <?php elseif($gv!==null): ?><span class="grade-val <?= $gcls ?>"><?= number_format($gv,2) ?></span>
        <?php else: ?>—<?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <div class="card-footer">
    <span style="font-size:12px;color:var(--text-3);"><?= count($rows) ?> grade<?= count($rows)!=1?'s':'' ?> on record</span>
  </div>
  <?php endif; ?>
</div>
<?php include '../includes/footer.php'; ?>
