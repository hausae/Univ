<?php
define('IN_SUBFOLDER',true); session_start();
require_once '../includes/db.php'; require_once '../includes/auth.php';
require_login('faculty');
$fid=$_SESSION['user_id']; $sem=active_semester($conn);

// Handle approve/reject
if($_SERVER['REQUEST_METHOD']==='POST'){
    $rid=(int)($_POST['request_id']??0);
    $action=$_POST['action']??'';
    $new=$action==='approve'?'approved':'rejected';
    $now=date('Y-m-d H:i:s');
    $conn->query("UPDATE add_drop_requests SET status='$new',processed_at='$now',processed_by=$fid WHERE request_id=$rid");
    $req=$conn->query("SELECT r.*,c.course_code,c.course_title,s2.student_id AS sid,s2.full_name AS sname FROM add_drop_requests r JOIN courses c ON c.course_id=r.course_id JOIN students s2 ON s2.student_id=r.student_id WHERE r.request_id=$rid")->fetch_assoc();    if($req && $action==='approve'){
        if($req['request_type']==='drop'){
            $conn->query("UPDATE enrollments SET status='dropped' WHERE student_id={$req['student_id']} AND course_id={$req['course_id']} AND semester_id={$sem['semester_id']} AND status NOT IN ('dropped','rejected')");
        } else {
            $chk=$conn->query("SELECT enrollment_id FROM enrollments WHERE student_id={$req['student_id']} AND course_id={$req['course_id']} AND semester_id={$sem['semester_id']}")->fetch_assoc();
            if($chk) $conn->query("UPDATE enrollments SET status='approved' WHERE enrollment_id={$chk['enrollment_id']}");
            else $conn->query("INSERT INTO enrollments (student_id,course_id,semester_id,status) VALUES ({$req['student_id']},{$req['course_id']},{$sem['semester_id']},'approved')");
        }
        add_notification($conn,'student',$req['sid'],
            "Your ".strtoupper($req['request_type'])." request for {$req['course_code']} — {$req['course_title']} has been APPROVED by faculty.");
        flash('success',ucfirst($req['request_type'])." request approved for {$req['sname']} ({$req['course_code']}).");
    } elseif($req){
        add_notification($conn,'student',$req['sid'],
            "Your ".strtoupper($req['request_type'])." request for {$req['course_code']} — {$req['course_title']} has been REJECTED by faculty.");
        flash('error',ucfirst($req['request_type'])." request rejected for {$req['sname']} ({$req['course_code']}).");
    }
    header('Location: approve_addrop.php'); exit;
}

$tab=$_GET['tab']??'add';

$add_rows=[];
$r=$conn->query("SELECT r.request_id,r.reason,r.requested_at,s2.student_code,s2.full_name AS sname,c.course_code,c.course_title FROM add_drop_requests r JOIN students s2 ON s2.student_id=r.student_id JOIN courses c ON c.course_id=r.course_id WHERE r.status='pending' AND r.request_type='add' ORDER BY r.requested_at ASC");
while($row=$r->fetch_assoc()) $add_rows[]=$row;

$drop_rows=[];
$r=$conn->query("SELECT r.request_id,r.reason,r.requested_at,s2.student_code,s2.full_name AS sname,c.course_code,c.course_title FROM add_drop_requests r JOIN students s2 ON s2.student_id=r.student_id JOIN courses c ON c.course_id=r.course_id WHERE r.status='pending' AND r.request_type='drop' ORDER BY r.requested_at ASC");
while($row=$r->fetch_assoc()) $drop_rows[]=$row;

$page_title='Approve Add/Drop'; $active_nav='addrop';
include '../includes/header.php';
?>

<!-- Tab buttons matching wireframe (Add Requests / Drop Requests) -->
<div class="tabs">
  <button class="tab-btn <?= $tab==='add'?'active':'' ?>" onclick="setTab('add')">
    Add Requests <?php if(count($add_rows)>0): ?><span class="pill pill-pending" style="margin-left:5px;"><?= count($add_rows) ?></span><?php endif; ?>
  </button>
  <button class="tab-btn <?= $tab==='drop'?'active':'' ?>" onclick="setTab('drop')">
    Drop Requests <?php if(count($drop_rows)>0): ?><span class="pill pill-pending" style="margin-left:5px;"><?= count($drop_rows) ?></span><?php endif; ?>
  </button>
</div>

<!-- Add requests panel -->
<div class="tab-panel <?= $tab==='add'?'active':'' ?>" id="panel-add">
  <div class="card">
    <div class="card-header">
      <span class="card-title">Add Requests</span>
      <span style="font-size:12px;color:var(--text-3);"><?= count($add_rows) ?> pending</span>
    </div>
    <?php if(empty($add_rows)): ?>
    <div class="card-body"><div class="empty-state"><p>No pending add requests.</p></div></div>
    <?php else: ?>
    <div class="table-wrap"><table>
      <thead><tr><th>Student ID</th><th>Student Name</th><th>Subject</th><th>Reason</th><th>Date</th><th>Action</th></tr></thead>
      <tbody><?php foreach($add_rows as $r): ?>
      <tr>
        <td class="td-code"><?= htmlspecialchars($r['student_code']) ?></td>
        <td><?= htmlspecialchars($r['sname']) ?></td>
        <td>
          <strong><?= htmlspecialchars($r['course_code']) ?></strong><br>
          <span style="font-size:11.5px;color:var(--text-3);"><?= htmlspecialchars($r['course_title']) ?></span>
        </td>
        <td style="font-size:12px;color:var(--text-3);"><?= $r['reason']?htmlspecialchars(substr($r['reason'],0,40)).'…':'—' ?></td>
        <td style="font-size:12px;color:var(--text-3);"><?= date('M d, Y',strtotime($r['requested_at'])) ?></td>
        <td>
          <div style="display:flex;gap:5px;">
            <form method="POST" style="display:inline;">
              <input type="hidden" name="request_id" value="<?= $r['request_id'] ?>">
              <input type="hidden" name="action" value="approve">
              <button type="submit" class="btn btn-green btn-sm" onclick="return confirm('Approve add request?')">Approve</button>
            </form>
            <form method="POST" style="display:inline;">
              <input type="hidden" name="request_id" value="<?= $r['request_id'] ?>">
              <input type="hidden" name="action" value="reject">
              <button type="submit" class="btn btn-red btn-sm" onclick="return confirm('Reject this request?')">Reject</button>
            </form>
          </div>
        </td>
      </tr>
      <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
  </div>
</div>

<!-- Drop requests panel -->
<div class="tab-panel <?= $tab==='drop'?'active':'' ?>" id="panel-drop">
  <div class="card">
    <div class="card-header">
      <span class="card-title">Drop Requests</span>
      <span style="font-size:12px;color:var(--text-3);"><?= count($drop_rows) ?> pending</span>
    </div>
    <?php if(empty($drop_rows)): ?>
    <div class="card-body"><div class="empty-state"><p>No pending drop requests.</p></div></div>
    <?php else: ?>
    <div class="table-wrap"><table>
      <thead><tr><th>Student ID</th><th>Student Name</th><th>Subject</th><th>Reason</th><th>Date</th><th>Action</th></tr></thead>
      <tbody><?php foreach($drop_rows as $r): ?>
      <tr>
        <td class="td-code"><?= htmlspecialchars($r['student_code']) ?></td>
        <td><?= htmlspecialchars($r['sname']) ?></td>
        <td>
          <strong><?= htmlspecialchars($r['course_code']) ?></strong><br>
          <span style="font-size:11.5px;color:var(--text-3);"><?= htmlspecialchars($r['course_title']) ?></span>
        </td>
        <td style="font-size:12px;color:var(--text-3);"><?= $r['reason']?htmlspecialchars(substr($r['reason'],0,40)).'…':'—' ?></td>
        <td style="font-size:12px;color:var(--text-3);"><?= date('M d, Y',strtotime($r['requested_at'])) ?></td>
        <td>
          <div style="display:flex;gap:5px;">
            <form method="POST" style="display:inline;">
              <input type="hidden" name="request_id" value="<?= $r['request_id'] ?>">
              <input type="hidden" name="action" value="approve">
              <button type="submit" class="btn btn-green btn-sm" onclick="return confirm('Approve drop request?')">Approve</button>
            </form>
            <form method="POST" style="display:inline;">
              <input type="hidden" name="request_id" value="<?= $r['request_id'] ?>">
              <input type="hidden" name="action" value="reject">
              <button type="submit" class="btn btn-red btn-sm" onclick="return confirm('Reject this request?')">Reject</button>
            </form>
          </div>
        </td>
      </tr>
      <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
  </div>
</div>

<script>
function setTab(name){
  document.querySelectorAll('.tab-btn').forEach((b,i)=>b.classList.toggle('active',(i===0&&name==='add')||(i===1&&name==='drop')));
  document.querySelectorAll('.tab-panel').forEach(p=>p.classList.remove('active'));
  document.getElementById('panel-'+name).classList.add('active');
}
</script>
<?php include '../includes/footer.php'; ?>
