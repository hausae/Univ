<?php
define('IN_SUBFOLDER',true); session_start();
require_once '../includes/db.php'; require_once '../includes/auth.php';
require_login('faculty');
$fid=$_SESSION['user_id']; $sem=active_semester($conn);

// ── SAVE SINGLE STUDENT GRADE (from student-specific modal) ─────────────────
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_single_grade'])){
    $eid    = (int)($_POST['enrollment_id'] ?? 0);
    $gval   = trim($_POST['grade'] ?? '');
    $remarks= trim($_POST['remarks'] ?? '');

    $valid  = ['1.00','1.25','1.50','1.75','2.00','2.25','2.50','2.75','3.00','5.00'];
    $is_inc = strtoupper($gval) === 'INC';
    $gnum   = is_numeric($gval) ? number_format((float)$gval, 2) : null;

    if(!$is_inc && !in_array($gnum, $valid)){
        flash('error','Invalid grade value. Use 1.00–5.00 or INC.');
        header('Location: submit_grades.php?course_id='.($_POST['back_course_id']??''));exit;
    }

    // Verify enrollment is approved/confirmed and belongs to a course this faculty teaches
    $enr = $conn->query("
        SELECT e.enrollment_id, e.student_id, e.course_id, e.semester_id, e.status,
               c.course_code, c.course_title, c.faculty_id,
               s2.full_name AS sname, s2.student_code, s2.student_id AS sid,
               sem.semester_name, sem.school_year
        FROM enrollments e
        JOIN courses c ON c.course_id = e.course_id
        JOIN students s2 ON s2.student_id = e.student_id
        JOIN semesters sem ON sem.semester_id = e.semester_id
        WHERE e.enrollment_id = $eid
          AND e.status IN ('approved','confirmed')
          AND c.faculty_id = $fid
    ")->fetch_assoc();

    if(!$enr){
        flash('error','Student not found or not enrolled in your subject.');
        header('Location: submit_grades.php?course_id='.($_POST['back_course_id']??''));exit;
    }

    $sem_label = $enr['semester_name'].', AY '.$enr['school_year'];

    if($is_inc){
        $stmt=$conn->prepare("INSERT INTO grades (enrollment_id,grade,remarks,submitted_by) VALUES (?,NULL,'INC',?)
            ON DUPLICATE KEY UPDATE grade=NULL,remarks='INC',submitted_by=?,updated_at=NOW()");
        $stmt->bind_param('iii',$eid,$fid,$fid);
    } else {
        $g = (float)$gnum;
        if(!$remarks) $remarks = $g <= 3.0 ? 'Passed' : 'Failed';
        $stmt=$conn->prepare("INSERT INTO grades (enrollment_id,grade,remarks,submitted_by) VALUES (?,?,?,?)
            ON DUPLICATE KEY UPDATE grade=?,remarks=?,submitted_by=?,updated_at=NOW()");
        $stmt->bind_param('idssdsi',$eid,$g,$remarks,$fid,$g,$remarks,$fid);
    }
    $stmt->execute(); $stmt->close();

    // Confirm enrollment
    $conn->query("UPDATE enrollments SET status='confirmed' WHERE enrollment_id=$eid");

    // Notify student with full detail
    add_notification($conn,'student',$enr['sid'],
        "Grade posted for {$enr['course_code']} — {$enr['course_title']} ({$sem_label}): ".
        ($is_inc ? 'INC (Incomplete)' : $gnum.' — '.($gnum<=3.00?'Passed':'Failed')).".");

    flash('success',"Grade saved for {$enr['sname']} ({$enr['course_code']}): ".($is_inc?'INC':$gnum).".");
    header('Location: submit_grades.php?course_id='.($enr['course_id']));exit;
}

// ── SAVE BULK GRADES (course grade sheet) ───────────────────────────────────
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_grades'])){
    $grades = $_POST['grade'] ?? [];
    $saved  = 0;
    $valid  = ['1.00','1.25','1.50','1.75','2.00','2.25','2.50','2.75','3.00','5.00'];

    foreach($grades as $eid => $gval){
        $eid   = (int)$eid;
        $gval  = trim($gval);
        if($gval === '') continue;

        $is_inc = strtoupper($gval) === 'INC';
        $gnum   = is_numeric($gval) ? number_format((float)$gval, 2) : null;
        if(!$is_inc && !in_array($gnum, $valid)) continue;

        $enr = $conn->query("
            SELECT e.student_id, e.course_id, e.semester_id,
                   c.course_code, c.course_title, c.faculty_id,
                   s2.student_id AS sid, s2.full_name AS sname,
                   sem.semester_name, sem.school_year
            FROM enrollments e
            JOIN courses c ON c.course_id = e.course_id
            JOIN students s2 ON s2.student_id = e.student_id
            JOIN semesters sem ON sem.semester_id = e.semester_id
            WHERE e.enrollment_id = $eid
              AND e.status IN ('approved','confirmed')
              AND c.faculty_id = $fid
        ")->fetch_assoc();
        if(!$enr) continue;

        $sem_label = $enr['semester_name'].', AY '.$enr['school_year'];

        if($is_inc){
            $stmt=$conn->prepare("INSERT INTO grades (enrollment_id,grade,remarks,submitted_by) VALUES (?,NULL,'INC',?)
                ON DUPLICATE KEY UPDATE grade=NULL,remarks='INC',submitted_by=?,updated_at=NOW()");
            $stmt->bind_param('iii',$eid,$fid,$fid);
        } else {
            $g=(float)$gnum; $rmk=$g<=3.0?'Passed':'Failed';
            $stmt=$conn->prepare("INSERT INTO grades (enrollment_id,grade,remarks,submitted_by) VALUES (?,?,?,?)
                ON DUPLICATE KEY UPDATE grade=?,remarks=?,submitted_by=?,updated_at=NOW()");
            $stmt->bind_param('idssdsi',$eid,$g,$rmk,$fid,$g,$rmk,$fid);
        }
        $stmt->execute(); $stmt->close();
        $conn->query("UPDATE enrollments SET status='confirmed' WHERE enrollment_id=$eid");

        add_notification($conn,'student',$enr['sid'],
            "Grade posted for {$enr['course_code']} — {$enr['course_title']} ({$sem_label}): ".
            ($is_inc ? 'INC (Incomplete)' : $gnum.' — '.($gnum<=3.00?'Passed':'Failed')).".");
        $saved++;
    }
    flash('success',"$saved grade".($saved!=1?'s':'')." saved successfully.");
    header('Location: submit_grades.php?course_id='.($_GET['course_id']??''));exit;
}

// ── LOAD DATA ────────────────────────────────────────────────────────────────
$filter_cid    = (int)($_GET['course_id'] ?? 0);
$search_student= trim($_GET['search_student'] ?? '');
$view_mode     = $_GET['mode'] ?? 'course'; // 'course' or 'student'
$filter_sem_id = $sem ? $sem['semester_id'] : 0;

// My courses this semester
$my_courses = [];
if($sem){
    $r=$conn->query("SELECT course_id,course_code,course_title FROM courses
        WHERE faculty_id=$fid AND semester_id={$sem['semester_id']} ORDER BY course_code");
    while($row=$r->fetch_assoc()) $my_courses[]=$row;
}
if(!$filter_cid && !empty($my_courses)) $filter_cid=$my_courses[0]['course_id'];

// Course grade sheet
$course_rows = [];
if($filter_cid && $view_mode==='course'){
    $r=$conn->query("
        SELECT e.enrollment_id, e.status,
               s2.student_id, s2.student_code, s2.full_name AS sname, s2.program, s2.year_level,
               c.course_code, c.course_title, c.units,
               g.grade, g.remarks, g.submitted_at, g.updated_at
        FROM enrollments e
        JOIN students s2 ON s2.student_id = e.student_id
        JOIN courses c   ON c.course_id   = e.course_id
        LEFT JOIN grades g ON g.enrollment_id = e.enrollment_id
        WHERE e.status IN ('approved','confirmed')
          AND e.semester_id = $filter_sem_id
          AND c.course_id   = $filter_cid
          AND c.faculty_id  = $fid
        ORDER BY s2.full_name ASC
    ");
    while($row=$r->fetch_assoc()) $course_rows[]=$row;
}

// Student search results
$student_results = [];
if($search_student && $view_mode==='student'){
    $ss = $conn->real_escape_string($search_student);
    $r  = $conn->query("
        SELECT s2.student_id, s2.student_code, s2.full_name, s2.program, s2.year_level
        FROM students s2
        WHERE s2.full_name LIKE '%$ss%' OR s2.student_code LIKE '%$ss%'
        ORDER BY s2.full_name LIMIT 20
    ");
    while($row=$r->fetch_assoc()) $student_results[]=$row;
}

// Single student grade sheet (for grading by student)
$sel_student_id = (int)($_GET['student_id'] ?? 0);
$student_subjects = [];
$sel_student = null;
if($sel_student_id && $view_mode==='student'){
    $sel_student = $conn->query("SELECT * FROM students WHERE student_id=$sel_student_id")->fetch_assoc();
    if($sel_student && $filter_sem_id){
        $r = $conn->query("
            SELECT e.enrollment_id, e.status,
                   c.course_id, c.course_code, c.course_title, c.units, c.faculty_id,
                   sem.semester_name, sem.school_year,
                   g.grade, g.remarks, g.submitted_at
            FROM enrollments e
            JOIN courses c   ON c.course_id   = e.course_id
            JOIN semesters sem ON sem.semester_id = e.semester_id
            LEFT JOIN grades g ON g.enrollment_id = e.enrollment_id
            WHERE e.student_id = $sel_student_id
              AND e.semester_id = $filter_sem_id
              AND e.status IN ('approved','confirmed')
              AND c.faculty_id = $fid
            ORDER BY c.course_code
        ");
        while($row=$r->fetch_assoc()) $student_subjects[]=$row;
    }
}

$grade_opts=['1.00','1.25','1.50','1.75','2.00','2.25','2.50','2.75','3.00','5.00','INC'];
$page_title='Submit Grades'; $active_nav='submit_gr';
include '../includes/header.php';
?>

<!-- Grade entry modal (used by both views) -->
<div id="gradeModal" class="modal-overlay">
  <div class="modal">
    <div class="modal-title">Enter Grade</div>
    <div id="modalInfo" style="font-size:13px;color:var(--text-3);margin-bottom:14px;"></div>
    <form method="POST">
      <input type="hidden" name="save_single_grade" value="1">
      <input type="hidden" name="enrollment_id" id="modalEid">
      <input type="hidden" name="back_course_id" value="<?= $filter_cid ?>">
      <div class="form-group">
        <label class="form-label">Student</label>
        <input type="text" id="modalStudent" class="form-control" readonly style="background:var(--bg-subtle);color:var(--text-2);">
      </div>
      <div class="form-group">
        <label class="form-label">Subject</label>
        <input type="text" id="modalSubject" class="form-control" readonly style="background:var(--bg-subtle);color:var(--text-2);">
      </div>
      <div class="form-group">
        <label class="form-label">Grade <span style="color:var(--text-3);font-weight:400;">(1.00 = highest, 5.00 = failing)</span></label>
        <select name="grade" id="modalGrade" class="form-control" required>
          <option value="">— Select grade —</option>
          <?php foreach($grade_opts as $g): ?>
          <option value="<?= $g ?>"><?= $g ?><?= $g==='5.00'?' — Failing':($g==='INC'?' — Incomplete':'') ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Remarks <span style="color:var(--text-3);font-weight:400;">(auto-filled; optional override)</span></label>
        <input type="text" name="remarks" class="form-control" placeholder="Passed / Failed / INC" maxlength="50">
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" onclick="closeModal()">Cancel</button>
        <button type="submit" class="btn btn-green">Save Grade</button>
      </div>
    </form>
  </div>
</div>

<!-- View mode toggle + filters -->
<div class="flex-between mb-4" style="flex-wrap:wrap;gap:10px;">
  <div style="display:flex;gap:6px;">
    <a href="?mode=course&course_id=<?= $filter_cid ?>" class="btn btn-sm <?= $view_mode==='course'?'btn-brown':'btn-ghost' ?>">Grade by Subject</a>
    <a href="?mode=student" class="btn btn-sm <?= $view_mode==='student'?'btn-brown':'btn-ghost' ?>">Grade by Student</a>
  </div>
  <div class="sem-tag"><?= $sem?htmlspecialchars($sem['semester_name'].', AY '.$sem['school_year']):'No active semester' ?></div>
</div>

<?php if($view_mode==='course'): ?>
<!-- ════════ MODE 1: GRADE BY SUBJECT ════════ -->
<div class="flex-center gap-3 mb-4" style="flex-wrap:wrap;">
  <label style="font-size:12px;color:var(--text-3);">Subject:</label>
  <select class="form-control" style="width:auto;" onchange="location='?mode=course&course_id='+this.value">
    <?php if(empty($my_courses)): ?>
    <option>No subjects assigned</option>
    <?php endif; ?>
    <?php foreach($my_courses as $c): ?>
    <option value="<?= $c['course_id'] ?>" <?= $filter_cid==$c['course_id']?'selected':'' ?>>
      <?= htmlspecialchars($c['course_code'].' — '.$c['course_title']) ?>
    </option>
    <?php endforeach; ?>
  </select>
</div>

<div class="card">
  <div class="card-header">
    <span class="card-title">Grade Sheet — <?= !empty($my_courses)?htmlspecialchars(array_column($my_courses,'course_code')[array_search($filter_cid,array_column($my_courses,'course_id'))??0]):'Subject' ?></span>
    <span style="font-size:12px;color:var(--text-3);"><?= count($course_rows) ?> student<?= count($course_rows)!=1?'s':'' ?></span>
  </div>
  <?php if(empty($course_rows)): ?>
  <div class="card-body"><div class="empty-state"><p><?= empty($my_courses)?'No subjects assigned this semester.':'No approved/confirmed students in this subject.' ?></p></div></div>
  <?php else: ?>
  <form method="POST">
    <input type="hidden" name="save_grades" value="1">
    <div class="table-wrap"><table>
      <thead>
        <tr>
          <th>Student ID</th>
          <th>Student Name</th>
          <th>Program</th>
          <th>Year</th>
          <th>Status</th>
          <th>Current Grade</th>
          <th>Enter Grade</th>
          <th>Last Updated</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($course_rows as $r):
          $cur = $r['remarks']==='INC' ? 'INC' : ($r['grade']!==null ? number_format((float)$r['grade'],2) : '');
          $gv  = $r['grade']!==null ? (float)$r['grade'] : null;
        ?>
        <tr>
          <td class="td-code"><?= htmlspecialchars($r['student_code']) ?></td>
          <td>
            <strong><?= htmlspecialchars($r['sname']) ?></strong><br>
            <span style="font-size:11px;color:var(--text-3);">ID: <?= $r['student_id'] ?></span>
          </td>
          <td style="font-size:12px;color:var(--text-3);"><?= htmlspecialchars($r['program']) ?></td>
          <td style="font-size:12px;">Yr<?= $r['year_level'] ?></td>
          <td><span class="pill pill-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
          <td>
            <?php if($r['remarks']==='INC'): ?>
              <span class="grade-val inc">INC</span>
            <?php elseif($gv!==null): ?>
              <span class="grade-val <?= $gv<=3.0?'pass':'fail' ?>"><?= number_format($gv,2) ?></span>
              <span style="font-size:11px;color:var(--text-3);"> — <?= htmlspecialchars($r['remarks']) ?></span>
            <?php else: ?>
              <span style="color:var(--text-3);">Not yet graded</span>
            <?php endif; ?>
          </td>
          <td style="width:130px;">
            <select name="grade[<?= $r['enrollment_id'] ?>]" class="form-control" style="font-size:12px;">
              <option value="">— Keep —</option>
              <?php foreach($grade_opts as $g): ?>
              <option value="<?= $g ?>" <?= $cur===$g?'selected':'' ?>><?= $g ?><?= $g==='5.00'?' (F)':($g==='INC'?' (Inc)':'') ?></option>
              <?php endforeach; ?>
            </select>
          </td>
          <td style="font-size:11.5px;color:var(--text-3);">
            <?= $r['updated_at'] ? date('M d, Y',strtotime($r['updated_at'])) : ($r['submitted_at'] ? date('M d, Y',strtotime($r['submitted_at'])) : '—') ?>
          </td>
          <td>
            <button type="button" class="btn btn-ghost btn-sm"
              onclick="openModal(
                <?= $r['enrollment_id'] ?>,
                '<?= htmlspecialchars(addslashes($r['sname'])) ?> (<?= htmlspecialchars($r['student_code']) ?>)',
                '<?= htmlspecialchars(addslashes($r['course_code'])) ?> — <?= htmlspecialchars(addslashes($r['course_title'])) ?>',
                '<?= $cur ?>'
              )">Grade</button>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table></div>
    <div class="card-footer flex-between">
      <span style="font-size:12px;color:var(--text-3);">Bulk: Change dropdowns then click Save All. Individual: Click "Grade" button per row.</span>
      <button type="submit" class="btn btn-green">Save All Grades</button>
    </div>
  </form>
  <?php endif; ?>
</div>

<?php else: ?>
<!-- ════════ MODE 2: GRADE BY STUDENT ════════ -->
<div class="two-col" style="align-items:start;">

  <!-- Left: search panel -->
  <div class="card">
    <div class="card-header"><span class="card-title">Find Student</span></div>
    <div class="card-body">
      <form method="GET" style="display:flex;gap:8px;margin-bottom:14px;">
        <input type="hidden" name="mode" value="student">
        <input type="hidden" name="semester_id" value="<?= $filter_sem_id ?>">
        <input type="text" name="search_student" class="form-control" placeholder="Enter student name or ID…" value="<?= htmlspecialchars($search_student) ?>" style="flex:1;">
        <button type="submit" class="btn btn-brown btn-sm">Search</button>
      </form>

      <?php if($search_student && empty($student_results)): ?>
      <div class="empty-state" style="padding:20px;"><p>No students found for "<?= htmlspecialchars($search_student) ?>".</p></div>
      <?php elseif(!empty($student_results)): ?>
      <div class="table-wrap"><table>
        <thead><tr><th>Student ID</th><th>Name</th><th>Program</th><th></th></tr></thead>
        <tbody>
          <?php foreach($student_results as $s): ?>
          <tr>
            <td class="td-code"><?= htmlspecialchars($s['student_code']) ?></td>
            <td><?= htmlspecialchars($s['full_name']) ?><br><span style="font-size:11px;color:var(--text-3);">Year <?= $s['year_level'] ?></span></td>
            <td style="font-size:11.5px;color:var(--text-3);"><?= htmlspecialchars($s['program']) ?></td>
            <td>
              <a href="?mode=student&student_id=<?= $s['student_id'] ?>&search_student=<?= urlencode($search_student) ?>"
                 class="btn btn-brown btn-sm <?= $sel_student_id==$s['student_id']?'':'btn-outline' ?>">
                Select
              </a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table></div>
      <?php else: ?>
      <div style="color:var(--text-3);font-size:13px;">Search for a student by name or student ID to see their subjects.</div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Right: selected student subjects -->
  <div>
    <?php if($sel_student): ?>
    <!-- Student info card -->
    <div class="card mb-4">
      <div class="card-header"><span class="card-title">Student Information</span></div>
      <div class="card-body">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;">
          <div style="width:40px;height:40px;border-radius:8px;background:var(--brown-500);color:#fff;font-size:18px;font-weight:800;display:flex;align-items:center;justify-content:center;">
            <?= strtoupper(substr($sel_student['full_name'],0,1)) ?>
          </div>
          <div>
            <div style="font-size:15px;font-weight:700;"><?= htmlspecialchars($sel_student['full_name']) ?></div>
            <div class="td-code" style="font-size:12.5px;"><?= htmlspecialchars($sel_student['student_code']) ?></div>
          </div>
        </div>
        <table style="font-size:12.5px;width:100%;">
          <tr><td style="color:var(--text-3);padding:3px 0;width:90px;">Program</td><td><?= htmlspecialchars($sel_student['program']) ?></td></tr>
          <tr><td style="color:var(--text-3);padding:3px 0;">Year Level</td><td>Year <?= $sel_student['year_level'] ?></td></tr>
        </table>
      </div>
    </div>

    <!-- Subjects for grading -->
    <div class="card">
      <div class="card-header">
        <span class="card-title">Subjects — <?= $sem?htmlspecialchars($sem['semester_name'].', AY '.$sem['school_year']):'—' ?></span>
      </div>
      <?php if(empty($student_subjects)): ?>
      <div class="card-body"><div class="empty-state">
        <p>This student has no approved/confirmed subjects in your courses this semester.</p>
      </div></div>
      <?php else: ?>
      <div class="table-wrap"><table>
        <thead><tr><th>Code</th><th>Subject Title</th><th>Units</th><th>Status</th><th>Grade</th><th>Action</th></tr></thead>
        <tbody>
          <?php foreach($student_subjects as $s):
            $gv  = $s['grade']!==null ? (float)$s['grade'] : null;
            $cur = $s['remarks']==='INC' ? 'INC' : ($gv!==null ? number_format($gv,2) : '');
          ?>
          <tr>
            <td class="td-code"><?= htmlspecialchars($s['course_code']) ?></td>
            <td><?= htmlspecialchars($s['course_title']) ?></td>
            <td><?= $s['units'] ?></td>
            <td><span class="pill pill-<?= $s['status'] ?>"><?= ucfirst($s['status']) ?></span></td>
            <td>
              <?php if($s['remarks']==='INC'): ?><span class="grade-val inc">INC</span>
              <?php elseif($gv!==null): ?><span class="grade-val <?= $gv<=3.0?'pass':'fail' ?>"><?= number_format($gv,2) ?></span>
              <?php else: ?><span style="color:var(--text-3);">—</span><?php endif; ?>
            </td>
            <td>
              <button type="button" class="btn btn-brown btn-sm"
                onclick="openModal(
                  <?= $s['enrollment_id'] ?>,
                  '<?= htmlspecialchars(addslashes($sel_student['full_name'])) ?> (<?= htmlspecialchars($sel_student['student_code']) ?>)',
                  '<?= htmlspecialchars(addslashes($s['course_code'])) ?> — <?= htmlspecialchars(addslashes($s['course_title'])) ?>',
                  '<?= $cur ?>'
                )">
                <?= $cur ? 'Update Grade' : 'Add Grade' ?>
              </button>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table></div>
      <?php endif; ?>
    </div>

    <?php elseif(!$search_student): ?>
    <div class="card">
      <div class="card-body">
        <div class="empty-state">
          <p>Search for a student on the left to view their subjects and enter grades.</p>
        </div>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<script>
function openModal(eid, student, subject, currentGrade){
  document.getElementById('modalEid').value         = eid;
  document.getElementById('modalStudent').value     = student;
  document.getElementById('modalSubject').value     = subject;
  const sel = document.getElementById('modalGrade');
  // Pre-select current grade
  for(let i=0;i<sel.options.length;i++){
    sel.options[i].selected = (sel.options[i].value === currentGrade);
  }
  document.getElementById('modalInfo').textContent = 'Entering grade for: ' + student;
  document.getElementById('gradeModal').classList.add('open');
}
function closeModal(){
  document.getElementById('gradeModal').classList.remove('open');
}
document.getElementById('gradeModal').addEventListener('click',function(e){
  if(e.target===this) closeModal();
});
</script>
<?php include '../includes/footer.php'; ?>
