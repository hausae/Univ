<?php
define('IN_SUBFOLDER',true); session_start();
require_once '../includes/db.php'; require_once '../includes/auth.php';
require_login('faculty');
$fid=$_SESSION['user_id']; $name=$_SESSION['user_name'];
$faculty=$conn->query("SELECT * FROM faculty WHERE faculty_id=$fid")->fetch_assoc();
$sem=active_semester($conn);
$pe=(int)$conn->query("SELECT COUNT(*) c FROM enrollments WHERE status='pending'")->fetch_assoc()['c'];
$pa=(int)$conn->query("SELECT COUNT(*) c FROM add_drop_requests WHERE status='pending'")->fetch_assoc()['c'];
$sg=(int)$conn->query("SELECT COUNT(*) c FROM grades WHERE submitted_by=$fid")->fetch_assoc()['c'];
$ts=$sem?(int)$conn->query("SELECT COUNT(DISTINCT e.student_id) c FROM enrollments e JOIN courses c ON c.course_id=e.course_id WHERE c.faculty_id=$fid AND c.semester_id={$sem['semester_id']} AND e.status NOT IN ('dropped','rejected')")->fetch_assoc()['c']:0;
$pending_rows=[];
$r=$conn->query("SELECT e.enrollment_id,e.enrolled_at,s2.student_code,s2.full_name AS sname,c.course_code,c.course_title FROM enrollments e JOIN students s2 ON s2.student_id=e.student_id JOIN courses c ON c.course_id=e.course_id WHERE e.status='pending' ORDER BY e.enrolled_at ASC LIMIT 8");
while($row=$r->fetch_assoc()) $pending_rows[]=$row;
$page_title='Dashboard'; $active_nav='dashboard';
include '../includes/header.php';
?>

<!-- Welcome banner -->
<div class="welcome-banner">
  <div class="flex-between">
    <div>
      <h2>Welcome, <?= htmlspecialchars($name) ?></h2>
      <div class="sub">Faculty ID: <?= htmlspecialchars($faculty['faculty_code']) ?> &nbsp;&bull;&nbsp; Department: <?= htmlspecialchars($faculty['department']) ?></div>
    </div>
    <?php if($sem): ?>
    <div style="text-align:right;">
      <div style="font-size:11px;opacity:.6;margin-bottom:2px;">Active Semester</div>
      <div style="font-size:13px;font-weight:600;"><?= htmlspecialchars($sem['semester_name']) ?>, AY <?= htmlspecialchars($sem['school_year']) ?></div>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- Stat row -->
<div class="stat-row mb-5">
  <div class="stat-box b-amber">
    <div class="stat-box-label">Pending Enrollments</div>
    <div class="stat-box-value"><?= $pe ?></div>
  </div>
  <div class="stat-box b-brown">
    <div class="stat-box-label">Add/Drop Requests</div>
    <div class="stat-box-value"><?= $pa ?></div>
  </div>
  <div class="stat-box b-green">
    <div class="stat-box-label">Submitted Grades</div>
    <div class="stat-box-value"><?= $sg ?></div>
  </div>
  <div class="stat-box b-blue">
    <div class="stat-box-label">Total Subjects</div>
    <div class="stat-box-value"><?= $ts ?></div>
  </div>
</div>

<div class="two-col">
  <!-- Pending enrollments -->
  <div class="card">
    <div class="card-header">
      <span class="card-title">Pending Enrollments</span>
      <a href="enrollments.php" class="btn btn-brown btn-sm">View All</a>
    </div>
    <?php if(empty($pending_rows)): ?>
    <div class="card-body"><div class="empty-state"><p>No pending enrollment requests.</p></div></div>
    <?php else: ?>
    <div class="table-wrap"><table>
      <thead><tr><th>Student ID</th><th>Student Name</th><th>Subject</th><th>Date</th></tr></thead>
      <tbody><?php foreach($pending_rows as $r): ?>
      <tr>
        <td class="td-code"><?= htmlspecialchars($r['student_code']) ?></td>
        <td><?= htmlspecialchars($r['sname']) ?></td>
        <td><?= htmlspecialchars($r['course_code']) ?></td>
        <td style="font-size:12px;color:var(--text-3);"><?= date('M d, Y',strtotime($r['enrolled_at'])) ?></td>
      </tr>
      <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
  </div>

  <div style="display:flex;flex-direction:column;gap:14px;">
    <!-- Quick actions -->
    <div class="card">
      <div class="card-header"><span class="card-title">Quick Actions</span></div>
      <div class="card-body" style="display:flex;flex-direction:column;gap:8px;">
        <a href="enrollments.php" class="btn btn-brown btn-block">View Enrollments <?php if($pe>0): ?><span style="background:rgba(255,255,255,.25);padding:1px 7px;border-radius:10px;font-size:10.5px;margin-left:4px;"><?= $pe ?></span><?php endif; ?></a>
        <a href="verify.php" class="btn btn-outline btn-block">Verify Enrollment</a>
        <a href="approve_addrop.php" class="btn btn-ghost btn-block">Approve Add/Drop <?php if($pa>0): ?><span style="background:var(--brown-200);color:var(--brown-900);padding:1px 7px;border-radius:10px;font-size:10.5px;margin-left:4px;"><?= $pa ?></span><?php endif; ?></a>
        <a href="submit_grades.php" class="btn btn-ghost btn-block">Submit Grades</a>
        <a href="view_grades.php" class="btn btn-ghost btn-block">View Grades</a>
      </div>
    </div>
    <!-- Announcements -->
    <div class="card">
      <div class="card-header"><span class="card-title">Announcements</span></div>
      <div class="card-body" style="padding-top:8px;padding-bottom:8px;">
        <ul class="announce-list">
          <li>Please verify and approve enrollments on or before <?= $sem?date('M j, Y',strtotime($sem['enrollment_end'])):'the deadline' ?>.</li>
          <li>Final grades submission deadline: <?= $sem?date('M j, Y',strtotime($sem['end_date'])):'end of semester' ?>.</li>
        </ul>
      </div>
    </div>
  </div>
</div>
<?php include '../includes/footer.php'; ?>
