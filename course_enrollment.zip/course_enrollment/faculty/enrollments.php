<?php
define('IN_SUBFOLDER',true); session_start();
require_once '../includes/db.php'; require_once '../includes/auth.php';
require_login('faculty');
$fid=$_SESSION['user_id'];
$sem=active_semester($conn);
$filter_cid=(int)($_GET['course_id']??0);
$filter_sem=$_GET['semester_id']??($sem?$sem['semester_id']:'');

// My courses for filter dropdown
$my_courses=[];
if($sem){$r=$conn->query("SELECT course_id,course_code,course_title FROM courses WHERE faculty_id=$fid AND semester_id={$sem['semester_id']} ORDER BY course_code");while($row=$r->fetch_assoc()) $my_courses[]=$row;}

$where=["1=1"];
if($filter_sem) $where[]="e.semester_id=".(int)$filter_sem;
if($filter_cid) $where[]="c.course_id=$filter_cid";
$rows=[];
$r=$conn->query("SELECT e.enrollment_id,e.status,e.enrolled_at,s2.student_id,s2.student_code,s2.full_name AS sname,c.course_code,c.course_title,c.units,sem.semester_name,sem.school_year FROM enrollments e JOIN students s2 ON s2.student_id=e.student_id JOIN courses c ON c.course_id=e.course_id JOIN semesters sem ON sem.semester_id=e.semester_id WHERE ".implode(' AND ',$where)." ORDER BY e.enrolled_at DESC LIMIT 100");
while($row=$r->fetch_assoc()) $rows[]=$row;
$page_title='View Enrollments'; $active_nav='enrollments';
include '../includes/header.php';
?>
<div class="card">
  <div class="card-header">
    <span class="card-title">View Enrollments</span>
    <div class="flex-center gap-2" style="flex-wrap:wrap;">
      <div class="flex-center gap-2">
        <label style="font-size:12px;color:var(--text-3);white-space:nowrap;">Filter by Subject:</label>
        <select class="form-control" style="width:auto;font-size:12.5px;" onchange="applyFilter(this,'course')">
          <option value="0">All</option>
          <?php foreach($my_courses as $c): ?>
          <option value="<?= $c['course_id'] ?>" <?= $filter_cid==$c['course_id']?'selected':'' ?>><?= htmlspecialchars($c['course_code']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="flex-center gap-2">
        <label style="font-size:12px;color:var(--text-3);white-space:nowrap;">Semester:</label>
        <select class="form-control" style="width:auto;font-size:12.5px;" onchange="applyFilter(this,'sem')">
          <?php
          $all_sems=$conn->query("SELECT * FROM semesters ORDER BY start_date DESC");
          while($s=$all_sems->fetch_assoc()):
          ?><option value="<?= $s['semester_id'] ?>" <?= $filter_sem==$s['semester_id']?'selected':'' ?>><?= htmlspecialchars($s['semester_name'].', AY '.$s['school_year']) ?></option>
          <?php endwhile; ?>
        </select>
      </div>
    </div>
  </div>
  <?php if(empty($rows)): ?>
  <div class="card-body"><div class="empty-state"><p>No enrollment records found.</p></div></div>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>Student ID</th><th>Student Name</th><th>Subject</th><th>Units</th><th>Status</th><th>Date</th><th>Action</th></tr></thead>
    <tbody><?php foreach($rows as $e): ?>
    <tr>
      <td class="td-code"><?= htmlspecialchars($e['student_code']) ?></td>
      <td><?= htmlspecialchars($e['sname']) ?></td>
      <td>
        <strong><?= htmlspecialchars($e['course_code']) ?></strong><br>
        <span style="font-size:11.5px;color:var(--text-3);"><?= htmlspecialchars($e['course_title']) ?></span>
      </td>
      <td><?= $e['units'] ?></td>
      <td><span class="pill pill-<?= $e['status'] ?>"><?= ucfirst($e['status']) ?></span></td>
      <td style="font-size:12px;color:var(--text-3);"><?= date('M d, Y',strtotime($e['enrolled_at'])) ?></td>
      <td>
        <?php if($e['status']==='pending'): ?>
        <a href="verify.php?enrollment_id=<?= $e['enrollment_id'] ?>" class="btn btn-brown btn-sm">View</a>
        <?php else: ?>
        <a href="verify.php?enrollment_id=<?= $e['enrollment_id'] ?>" class="btn btn-ghost btn-sm">View</a>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <div class="card-footer">
    <span style="font-size:12px;color:var(--text-3);"><?= count($rows) ?> record<?= count($rows)!=1?'s':'' ?> found</span>
  </div>
  <?php endif; ?>
</div>
<script>
function applyFilter(el, type) {
  const url = new URL(window.location);
  if(type==='course') url.searchParams.set('course_id', el.value);
  if(type==='sem')    url.searchParams.set('semester_id', el.value);
  window.location = url;
}
</script>
<?php include '../includes/footer.php'; ?>
