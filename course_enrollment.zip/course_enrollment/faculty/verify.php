<?php
define('IN_SUBFOLDER',true); session_start();
require_once '../includes/db.php'; require_once '../includes/auth.php';
require_login('faculty');
$fid=$_SESSION['user_id'];
$sem=active_semester($conn);

// Handle approve/reject
if($_SERVER['REQUEST_METHOD']==='POST'){
    $eid=(int)($_POST['enrollment_id']??0);
    $action=$_POST['action']??'';
    $enr=$conn->query("SELECT e.*,c.course_code,c.course_title,s2.full_name AS sname,s2.student_id AS sid FROM enrollments e JOIN courses c ON c.course_id=e.course_id JOIN students s2 ON s2.student_id=e.student_id WHERE e.enrollment_id=$eid")->fetch_assoc();    if($enr){
        // Get semester info for richer notification
        $sem_info=$conn->query("SELECT semester_name,school_year FROM semesters WHERE semester_id={$enr['semester_id']}")->fetch_assoc();
        $sem_label=$sem_info?$sem_info['semester_name'].', AY '.$sem_info['school_year']:'';
        if($action==='approve'){
            $count=enrolled_count($conn,$enr['course_id'],$enr['semester_id']);
            $cap=(int)$conn->query("SELECT capacity FROM courses WHERE course_id={$enr['course_id']}")->fetch_assoc()['capacity'];
            if($count>=$cap){flash('error','Cannot approve — subject is now full.');header('Location: verify.php');exit;}
            $conn->query("UPDATE enrollments SET status='approved' WHERE enrollment_id=$eid");
            add_notification($conn,'student',$enr['sid'],
                "Your enrollment in {$enr['course_code']} — {$enr['course_title']} ({$sem_label}) has been APPROVED by faculty.");
            flash('success',"Enrollment approved for {$enr['sname']} ({$enr['course_code']}).");
        } else {
            $conn->query("UPDATE enrollments SET status='rejected' WHERE enrollment_id=$eid");
            add_notification($conn,'student',$enr['sid'],
                "Your enrollment in {$enr['course_code']} — {$enr['course_title']} ({$sem_label}) has been REJECTED by faculty.");
            flash('error',"Enrollment rejected for {$enr['sname']} ({$enr['course_code']}).");
        }
    }
    header('Location: verify.php'); exit;
}

// Single enrollment view
$view_eid=(int)($_GET['enrollment_id']??0);
$view_enr=null; $check_result=null;
if($view_eid){
    $view_enr=$conn->query("SELECT e.*,c.course_code,c.course_title,c.units,c.capacity,s2.student_code,s2.full_name AS sname,s2.program,s2.year_level FROM enrollments e JOIN courses c ON c.course_id=e.course_id JOIN students s2 ON s2.student_id=e.student_id WHERE e.enrollment_id=$view_eid")->fetch_assoc();
    if($view_enr){
        // Check prerequisites
        $pq=check_prerequisites($conn,$view_enr['course_id'],$view_enr['student_id']);
        // Check schedule conflicts (same semester, would just be capacity here)
        $count=enrolled_count($conn,$view_enr['course_id'],$view_enr['semester_id']);
        $has_conflict=false; // simplified — no time slots in DB
        $within_load=true;   // simplified
        $check_result=['prereq_met'=>$pq['met'],'prereqs'=>$pq['prereqs'],'no_conflict'=>!$has_conflict,'within_load'=>$within_load,'slots_left'=>max(0,$view_enr['capacity']-$count),'eligible'=>$pq['met']&&!$has_conflict&&$within_load&&($count<$view_enr['capacity'])];
    }
}

// Pending list
$pending=[];
$r=$conn->query("SELECT e.enrollment_id,e.enrolled_at,s2.student_code,s2.full_name AS sname,c.course_code,c.course_title FROM enrollments e JOIN students s2 ON s2.student_id=e.student_id JOIN courses c ON c.course_id=e.course_id WHERE e.status='pending' ORDER BY e.enrolled_at ASC LIMIT 50");
while($row=$r->fetch_assoc()) $pending[]=$row;

$page_title='Verify Enrollment'; $active_nav='verify';
include '../includes/header.php';
?>

<?php if($view_enr): ?>
<!-- Single enrollment verify view — SCREEN 4 -->
<div class="mb-4"><a href="verify.php" class="btn btn-ghost btn-sm">&larr; Back to list</a></div>

<div class="sidebar-layout">
  <!-- Check panel -->
  <div class="card">
    <div class="card-header"><span class="card-title">Verify Enrollment</span></div>
    <div class="card-body">
      <div style="font-size:13px;font-weight:600;margin-bottom:2px;"><?= htmlspecialchars($view_enr['sname']) ?> (<?= htmlspecialchars($view_enr['student_code']) ?>)</div>
      <div style="font-size:12.5px;color:var(--text-3);margin-bottom:14px;"><?= htmlspecialchars($view_enr['course_code']) ?> — <?= htmlspecialchars($view_enr['course_title']) ?></div>

      <div class="section-label">Check Requirements</div>
      <div class="check-list">
        <div class="check-item">
          <div class="check-dot <?= $check_result['prereq_met']?'pass':'fail' ?>"><?= $check_result['prereq_met']?'&#10003;':'&#10007;' ?></div>
          <span><?= $check_result['prereq_met']?'Completed Prerequisite':'Missing Prerequisites' ?></span>
        </div>
        <div class="check-item">
          <div class="check-dot <?= $check_result['no_conflict']?'pass':'fail' ?>"><?= $check_result['no_conflict']?'&#10003;':'&#10007;' ?></div>
          <span>No Schedule Conflict</span>
        </div>
        <div class="check-item">
          <div class="check-dot <?= $check_result['within_load']?'pass':'fail' ?>"><?= $check_result['within_load']?'&#10003;':'&#10007;' ?></div>
          <span>Within Unit Load</span>
        </div>
        <div class="check-item">
          <div class="check-dot <?= $check_result['slots_left']>0?'pass':'fail' ?>"><?= $check_result['slots_left']>0?'&#10003;':'&#10007;' ?></div>
          <span>No Holds / Violations &nbsp; (<?= $check_result['slots_left'] ?> slot<?= $check_result['slots_left']!=1?'s':'' ?> left)</span>
        </div>
      </div>

      <div class="verify-status <?= $check_result['eligible']?'eligible':'ineligible' ?>">
        Status: <?= $check_result['eligible']?'Eligible':'Not Eligible' ?>
      </div>

      <?php if($view_enr['status']==='pending'): ?>
      <div class="verify-actions">
        <form method="POST" style="flex:1;">
          <input type="hidden" name="enrollment_id" value="<?= $view_eid ?>">
          <input type="hidden" name="action" value="reject">
          <button type="submit" class="btn btn-red btn-block" onclick="return confirm('Reject this enrollment?')">Reject</button>
        </form>
        <form method="POST" style="flex:1;">
          <input type="hidden" name="enrollment_id" value="<?= $view_eid ?>">
          <input type="hidden" name="action" value="approve">
          <button type="submit" class="btn btn-green btn-block" onclick="return confirm('Approve this enrollment?')" <?= !$check_result['eligible']?'disabled':'' ?>>Verify</button>
        </form>
      </div>
      <?php else: ?>
      <div style="margin-top:12px;text-align:center;">
        <span class="pill pill-<?= $view_enr['status'] ?>" style="font-size:12px;padding:5px 14px;"><?= ucfirst($view_enr['status']) ?></span>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Student info -->
  <div style="display:flex;flex-direction:column;gap:14px;">
    <div class="card">
      <div class="card-header"><span class="card-title">Student Information</span></div>
      <div class="card-body">
        <table style="font-size:13px;width:100%;">
          <tr><td style="color:var(--text-3);padding:5px 0;width:120px;">Name</td><td><strong><?= htmlspecialchars($view_enr['sname']) ?></strong></td></tr>
          <tr><td style="color:var(--text-3);padding:5px 0;">Student ID</td><td><?= htmlspecialchars($view_enr['student_code']) ?></td></tr>
          <tr><td style="color:var(--text-3);padding:5px 0;">Program</td><td><?= htmlspecialchars($view_enr['program']) ?></td></tr>
          <tr><td style="color:var(--text-3);padding:5px 0;">Year Level</td><td>Year <?= $view_enr['year_level'] ?></td></tr>
        </table>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><span class="card-title">Subject Information</span></div>
      <div class="card-body">
        <table style="font-size:13px;width:100%;">
          <tr><td style="color:var(--text-3);padding:5px 0;width:120px;">Code</td><td><strong class="td-code"><?= htmlspecialchars($view_enr['course_code']) ?></strong></td></tr>
          <tr><td style="color:var(--text-3);padding:5px 0;">Title</td><td><?= htmlspecialchars($view_enr['course_title']) ?></td></tr>
          <tr><td style="color:var(--text-3);padding:5px 0;">Units</td><td><?= $view_enr['units'] ?></td></tr>
          <tr><td style="color:var(--text-3);padding:5px 0;">Capacity</td><td><?= $check_result['slots_left'] ?> slot<?= $check_result['slots_left']!=1?'s':'' ?> remaining</td></tr>
          <tr><td style="color:var(--text-3);padding:5px 0;">Status</td><td><span class="pill pill-<?= $view_enr['status'] ?>"><?= ucfirst($view_enr['status']) ?></span></td></tr>
        </table>
      </div>
    </div>
  </div>
</div>

<?php else: ?>
<!-- Pending list -->
<div class="card">
  <div class="card-header">
    <span class="card-title">Pending Enrollments</span>
    <span style="font-size:12px;color:var(--text-3);"><?= count($pending) ?> request<?= count($pending)!=1?'s':'' ?> awaiting verification</span>
  </div>
  <?php if(empty($pending)): ?>
  <div class="card-body"><div class="empty-state"><p>No pending enrollment requests.</p></div></div>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>Student ID</th><th>Student Name</th><th>Subject</th><th>Date Submitted</th><th>Action</th></tr></thead>
    <tbody><?php foreach($pending as $p): ?>
    <tr>
      <td class="td-code"><?= htmlspecialchars($p['student_code']) ?></td>
      <td><?= htmlspecialchars($p['sname']) ?></td>
      <td>
        <strong><?= htmlspecialchars($p['course_code']) ?></strong><br>
        <span style="font-size:11.5px;color:var(--text-3);"><?= htmlspecialchars($p['course_title']) ?></span>
      </td>
      <td style="font-size:12px;color:var(--text-3);"><?= date('M d, Y',strtotime($p['enrolled_at'])) ?></td>
      <td><a href="verify.php?enrollment_id=<?= $p['enrollment_id'] ?>" class="btn btn-brown btn-sm">Verify</a></td>
    </tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
