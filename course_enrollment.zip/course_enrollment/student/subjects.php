<?php
define('IN_SUBFOLDER',true); session_start();
require_once '../includes/db.php'; require_once '../includes/auth.php';
require_login('student');
$sid=$_SESSION['user_id']; $sem=active_semester($conn);
$search=trim($_GET['search']??''); $sem_filter=$_GET['sem']??'all';
$where=$sem?"c.semester_id={$sem['semester_id']}":"1=0";
if($search){$s=$conn->real_escape_string($search);$where.=" AND (c.course_code LIKE '%$s%' OR c.course_title LIKE '%$s%')";}
$raw=$conn->query("SELECT c.*,f.full_name AS faculty_name,(SELECT e3.status FROM enrollments e3 WHERE e3.student_id=$sid AND e3.course_id=c.course_id AND e3.semester_id=c.semester_id LIMIT 1) AS my_status,(SELECT COUNT(*) FROM enrollments e2 WHERE e2.course_id=c.course_id AND e2.semester_id=c.semester_id AND e2.status NOT IN ('dropped','rejected')) AS enrolled_count FROM courses c LEFT JOIN faculty f ON f.faculty_id=c.faculty_id WHERE $where ORDER BY c.course_code");
$courses=[];
while($row=$raw->fetch_assoc()){$pq=check_prerequisites($conn,(int)$row['course_id'],$sid);$row['prereq_met']=$pq['met'];$row['prereqs']=$pq['prereqs'];$row['slots_left']=max(0,$row['capacity']-$row['enrolled_count']);$courses[]=$row;}
$page_title='View Subjects'; $active_nav='subjects'; include '../includes/header.php';
?>
<div class="card">
  <div class="card-header">
    <span class="card-title">View Subjects <?= $sem?'— '.htmlspecialchars($sem['semester_name'].', AY '.$sem['school_year']):'' ?></span>
    <div style="display:flex;gap:8px;align-items:center;">
      <span style="font-size:12px;color:var(--text-3);">Semester Offered:</span>
      <span class="sem-tag"><?= $sem?htmlspecialchars($sem['semester_name']):'N/A' ?></span>
      <form method="GET" style="display:flex;gap:6px;">
        <input type="text" name="search" class="form-control" style="width:180px;" placeholder="Search subject..." value="<?= htmlspecialchars($search) ?>">
        <button type="submit" class="btn btn-ghost btn-sm">Search</button>
        <?php if($search): ?><a href="subjects.php" class="btn btn-ghost btn-sm">Clear</a><?php endif; ?>
      </form>
    </div>
  </div>
  <?php if(empty($courses)): ?>
  <div class="card-body"><div class="empty-state"><p><?= $search?"No subjects match \"".htmlspecialchars($search)."\".":"No subjects available." ?></p></div></div>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>Code</th><th>Subject Title</th><th>Units</th><th>Prerequisite</th><th>Available Semester</th><th>Action</th></tr></thead>
    <tbody><?php foreach($courses as $c): ?>
    <tr>
      <td class="td-code"><?= htmlspecialchars($c['course_code']) ?></td>
      <td><?= htmlspecialchars($c['course_title']) ?></td>
      <td><?= $c['units'] ?></td>
      <td>
        <?php if(!empty($c['prereqs'])): ?>
          <?php foreach($c['prereqs'] as $p): ?>
          <span style="font-size:12px;color:<?= $p['passed']?'var(--green)':'var(--red)' ?>;font-weight:600;"><?= htmlspecialchars($p['course_code']) ?></span><br>
          <?php endforeach; ?>
        <?php else: ?><span style="color:var(--text-3);font-size:12px;">None</span><?php endif; ?>
      </td>
      <td style="font-size:12px;color:var(--text-3);"><?= $sem?htmlspecialchars($sem['semester_name']):'—' ?></td>
      <td>
        <?php if($c['my_status']): ?><span class="pill pill-<?= $c['my_status'] ?>"><?= ucfirst($c['my_status']) ?></span>
        <?php else: ?><a href="add_subject.php?course_id=<?= $c['course_id'] ?>" class="btn btn-ghost btn-sm">View</a><?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <div class="card-footer">
    <p style="font-size:12px;color:var(--text-3);">Note: If the prerequisite is not yet available, you may take other subjects or advance and take the prerequisite when it is offered.</p>
  </div>
  <?php endif; ?>
</div>
<?php include '../includes/footer.php'; ?>
