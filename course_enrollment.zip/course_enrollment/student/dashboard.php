<?php
define('IN_SUBFOLDER',true); session_start();
require_once '../includes/db.php'; require_once '../includes/auth.php';
require_login('student');
$sid=$_SESSION['user_id']; $name=$_SESSION['user_name'];
$student=$conn->query("SELECT * FROM students WHERE student_id=$sid")->fetch_assoc();
$sem=active_semester($conn);
$enrolled=(int)$conn->query("SELECT COUNT(*) c FROM enrollments WHERE student_id=$sid AND status NOT IN ('dropped','rejected') AND semester_id=".($sem?$sem['semester_id']:0))->fetch_assoc()['c'];
$total_units=(int)$conn->query("SELECT COALESCE(SUM(c.units),0) c FROM enrollments e JOIN courses c ON c.course_id=e.course_id WHERE e.student_id=$sid AND e.status NOT IN ('dropped','rejected') AND e.semester_id=".($sem?$sem['semester_id']:0))->fetch_assoc()['c'];
$gpa_r=$conn->query("SELECT AVG(g.grade) g FROM grades g JOIN enrollments e ON e.enrollment_id=g.enrollment_id WHERE e.student_id=$sid AND g.grade IS NOT NULL");
$gpa=$gpa_r->fetch_assoc()['g'];
$pending=(int)$conn->query("SELECT COUNT(*) c FROM enrollments WHERE student_id=$sid AND status='pending'")->fetch_assoc()['c'];
$standing=$pending>0?'Pending':'Good Standing';
$page_title='Dashboard'; $active_nav='dashboard';
include '../includes/header.php';
?>
<div class="welcome-banner">
  <div class="flex-between">
    <div>
      <h2>Welcome, <?= htmlspecialchars($name) ?></h2>
      <div class="sub">Student ID: <?= htmlspecialchars($student['student_code']) ?> &nbsp;&bull;&nbsp; Program: <?= htmlspecialchars($student['program']) ?></div>
    </div>
    <?php if($sem): ?>
    <div style="text-align:right;">
      <div style="font-size:11px;opacity:.6;margin-bottom:2px;">Current Semester</div>
      <div style="font-size:13px;font-weight:600;"><?= htmlspecialchars($sem['semester_name']) ?>, AY <?= htmlspecialchars($sem['school_year']) ?></div>
    </div>
    <?php endif; ?>
  </div>
  <div class="welcome-stats">
    <div class="ws-item"><div class="ws-value"><?= $enrolled ?></div><div class="ws-label">Enrolled Subjects</div></div>
    <div class="ws-item"><div class="ws-value"><?= $total_units ?></div><div class="ws-label">Total Units</div></div>
    <div class="ws-item"><div class="ws-value"><?= $gpa?number_format($gpa,2):'—' ?></div><div class="ws-label">GPA</div></div>
    <div class="ws-item"><div class="ws-value ws-status"><?= $standing ?></div><div class="ws-label">Status</div></div>
  </div>
</div>

<div class="two-col">
  <!-- Current semester subjects -->
  <?php
  $cur=[];
  if($sem){ $r=$conn->query("SELECT e.*,c.course_code,c.course_title,c.units,g.grade FROM enrollments e JOIN courses c ON c.course_id=e.course_id LEFT JOIN grades g ON g.enrollment_id=e.enrollment_id WHERE e.student_id=$sid AND e.semester_id={$sem['semester_id']} ORDER BY c.course_code"); while($row=$r->fetch_assoc()) $cur[]=$row; }
  ?>
  <div class="card">
    <div class="card-header">
      <span class="card-title">Enrolled Subjects — Current Semester</span>
      <a href="enrollment.php" class="btn btn-brown btn-sm">Submit Enrollment</a>
    </div>
    <?php if(empty($cur)): ?>
    <div class="card-body"><div class="empty-state"><p>No subjects enrolled this semester.</p><a href="add_subject.php" class="btn btn-brown btn-sm mt-3">Add Subject</a></div></div>
    <?php else: ?>
    <div class="table-wrap"><table>
      <thead><tr><th>Code</th><th>Subject Title</th><th>Units</th><th>Status</th></tr></thead>
      <tbody><?php foreach($cur as $c): ?>
      <tr>
        <td class="td-code"><?= htmlspecialchars($c['course_code']) ?></td>
        <td><?= htmlspecialchars($c['course_title']) ?></td>
        <td><?= $c['units'] ?></td>
        <td><span class="pill pill-<?= $c['status'] ?>"><?= ucfirst($c['status']) ?></span></td>
      </tr>
      <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
  </div>

  <div style="display:flex;flex-direction:column;gap:14px;">
    <!-- Period status -->
    <?php if($sem): ?>
    <div class="card">
      <div class="card-header"><span class="card-title">Enrollment Periods</span></div>
      <div class="card-body" style="padding:10px 16px;">
        <?php $eo=enrollment_open($conn); $ao=add_drop_open($conn); ?>
        <div style="display:flex;flex-direction:column;gap:8px;">
          <div class="flex-between" style="font-size:13px;">
            <span>Enrollment Period</span>
            <span class="pill <?= $eo?'pill-approved':'pill-dropped' ?>"><?= $eo?'Open':'Closed' ?></span>
          </div>
          <div style="font-size:11.5px;color:var(--text-3);"><?= date('M j',strtotime($sem['enrollment_start'])) ?> – <?= date('M j, Y',strtotime($sem['enrollment_end'])) ?></div>
          <div class="flex-between" style="font-size:13px;margin-top:4px;">
            <span>Add/Drop Period</span>
            <span class="pill <?= $ao?'pill-approved':'pill-dropped' ?>"><?= $ao?'Open':'Closed' ?></span>
          </div>
          <div style="font-size:11.5px;color:var(--text-3);"><?= date('M j',strtotime($sem['add_drop_start'])) ?> – <?= date('M j, Y',strtotime($sem['add_drop_end'])) ?></div>
        </div>
      </div>
    </div>
    <?php endif; ?>
    <!-- Announcements -->
    <div class="card">
      <div class="card-header"><span class="card-title">Announcements</span></div>
      <div class="card-body" style="padding-top:8px;padding-bottom:8px;">
        <ul class="announce-list">
          <?php if($sem): ?>
          <li>Enrollment for <?= htmlspecialchars($sem['semester_name']) ?> is <?= enrollment_open($conn)?'now open':'currently closed' ?>.</li>
          <li>Add/Drop period: <?= date('M j',strtotime($sem['add_drop_start'])) ?> – <?= date('M j, Y',strtotime($sem['add_drop_end'])) ?>.</li>
          <li>Classes start on <?= date('F j, Y',strtotime($sem['start_date'])) ?>.</li>
          <?php else: ?><li>No active semester at this time.</li><?php endif; ?>
        </ul>
      </div>
    </div>
  </div>
</div>
<?php include '../includes/footer.php'; ?>
