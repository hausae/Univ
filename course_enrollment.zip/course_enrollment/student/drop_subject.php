<?php
define('IN_SUBFOLDER',true); session_start();
require_once '../includes/db.php'; require_once '../includes/auth.php';
require_login('student');
$sid=$_SESSION['user_id']; $sem=active_semester($conn); $ao=add_drop_open($conn);

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['drop_course_id'])){
    if(!$ao){flash('error','Add/Drop period is closed.');header('Location: drop_subject.php');exit;}
    $cid=(int)$_POST['drop_course_id'];
    $dup=$conn->query("SELECT request_id FROM add_drop_requests WHERE student_id=$sid AND course_id=$cid AND request_type='drop' AND status='pending'")->fetch_assoc();
    if($dup){flash('error','You already have a pending drop request for this subject.');header('Location: drop_subject.php');exit;}
    $stmt=$conn->prepare("INSERT INTO add_drop_requests (student_id,course_id,request_type,reason) VALUES (?,?,'drop','Student requested drop')");
    $stmt->bind_param('ii',$sid,$cid);$stmt->execute();$stmt->close();
    $ci=$conn->query("SELECT course_code,faculty_id FROM courses WHERE course_id=$cid")->fetch_assoc();
    if($ci['faculty_id']) add_notification($conn,'faculty',$ci['faculty_id'],"{$_SESSION['user_name']} requested to DROP {$ci['course_code']}.");
    add_notification($conn,'student',$sid,"Drop request for {$ci['course_code']} submitted for approval.");
    flash('success','Drop request submitted. Awaiting faculty approval.');
    header('Location: drop_subject.php');exit;
}

$enrolled=[];
if($sem){
    $r=$conn->query("SELECT e.enrollment_id,e.status,c.course_id,c.course_code,c.course_title,c.units,(SELECT request_id FROM add_drop_requests WHERE student_id=$sid AND course_id=c.course_id AND request_type='drop' AND status='pending' LIMIT 1) AS pending_drop FROM enrollments e JOIN courses c ON c.course_id=e.course_id WHERE e.student_id=$sid AND e.semester_id={$sem['semester_id']} AND e.status NOT IN ('dropped','rejected') ORDER BY c.course_code");
    while($row=$r->fetch_assoc()) $enrolled[]=$row;
}
$page_title='Drop Subject'; $active_nav='drop_sub'; include '../includes/header.php';
?>
<?php if(!$ao): ?><div class="period-banner closed">Add/Drop period is currently closed. Drop requests cannot be submitted.</div><?php else: ?><div class="period-banner open">Add/Drop period is open. Click Drop to request removal of a subject.</div><?php endif; ?>

<div class="card">
  <div class="card-header">
    <span class="card-title">Current Enrolled Subjects</span>
    <span style="font-size:12px;color:var(--text-3);"><?= $sem?htmlspecialchars($sem['semester_name'].', AY '.$sem['school_year']):'—' ?></span>
  </div>
  <?php if(empty($enrolled)): ?>
  <div class="card-body"><div class="empty-state"><p>No subjects enrolled this semester.</p></div></div>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>Code</th><th>Subject Title</th><th>Units</th><th>Status</th><th>Action</th></tr></thead>
    <tbody><?php foreach($enrolled as $e): ?>
    <tr>
      <td class="td-code"><?= htmlspecialchars($e['course_code']) ?></td>
      <td><?= htmlspecialchars($e['course_title']) ?></td>
      <td><?= $e['units'] ?></td>
      <td><span class="pill pill-<?= $e['status'] ?>"><?= ucfirst($e['status']) ?></span></td>
      <td>
        <?php if($e['pending_drop']): ?>
        <span class="pill pill-pending" style="font-size:10.5px;">Drop Pending</span>
        <?php elseif($ao): ?>
        <form method="POST" style="display:inline;">
          <input type="hidden" name="drop_course_id" value="<?= $e['course_id'] ?>">
          <button type="submit" class="btn btn-drop" onclick="return confirm('Request to drop <?= htmlspecialchars(addslashes($e['course_code'])) ?>?')">Drop</button>
        </form>
        <?php else: ?>
        <button class="btn btn-drop" disabled>Drop</button>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <div class="card-footer">
    <p class="note-text">Note: Dropped subjects will be subject to approval.</p>
  </div>
  <?php endif; ?>
</div>
<?php include '../includes/footer.php'; ?>
