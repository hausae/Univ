<?php
define('IN_SUBFOLDER',true); session_start();
require_once '../includes/db.php'; require_once '../includes/auth.php';
require_login('student');
$sid=$_SESSION['user_id']; $sem=active_semester($conn); $eo=enrollment_open($conn);

// Submit enrollment
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['submit_enrollment'])){
    if(!$eo){flash('error','Enrollment period is closed.');header('Location: enrollment.php');exit;}
    $pending_count=(int)$conn->query("SELECT COUNT(*) c FROM enrollments WHERE student_id=$sid AND status='pending' AND semester_id={$sem['semester_id']}")->fetch_assoc()['c'];
    if($pending_count===0){flash('error','No pending subjects to submit. Please add subjects first.');header('Location: enrollment.php');exit;}
    // Notify faculty
    $fac_list=$conn->query("SELECT DISTINCT c.faculty_id FROM enrollments e JOIN courses c ON c.course_id=e.course_id WHERE e.student_id=$sid AND e.status='pending' AND e.semester_id={$sem['semester_id']}");
    while($f=$fac_list->fetch_assoc()) add_notification($conn,'faculty',$f['faculty_id'],"{$_SESSION['user_name']} has submitted enrollment for verification.");
    add_notification($conn,'student',$sid,"Your enrollment has been submitted for faculty verification.");
    flash('success','Enrollment submitted! Faculty will verify your subjects.');
    header('Location: enrollment.php?view=status');exit;
}

$view=$_GET['view']??'submit';

// Load subjects for current semester
$subjects=[];
if($sem){
    $r=$conn->query("SELECT e.*,c.course_code,c.course_title,c.units,g.grade FROM enrollments e JOIN courses c ON c.course_id=e.course_id LEFT JOIN grades g ON g.enrollment_id=e.enrollment_id WHERE e.student_id=$sid AND e.semester_id={$sem['semester_id']} AND e.status NOT IN ('dropped','rejected') ORDER BY c.course_code");
    while($row=$r->fetch_assoc()) $subjects[]=$row;
}
$total_units=array_sum(array_column($subjects,'units'));
$has_pending=count(array_filter($subjects,fn($s)=>$s['status']==='pending'))>0;
$all_approved=!empty($subjects) && empty(array_filter($subjects,fn($s)=>$s['status']==='pending'));

$page_title='Enrollment'; $active_nav='enroll'; include '../includes/header.php';
?>

<div class="tabs">
  <button class="tab-btn <?= $view!=='status'&&$view!=='enrolled'?'active':'' ?>" onclick="window.location='enrollment.php'">Submit Enrollment</button>
  <button class="tab-btn <?= $view==='status'?'active':'' ?>" onclick="window.location='enrollment.php?view=status'">Enrollment Status</button>
  <button class="tab-btn <?= $view==='enrolled'?'active':'' ?>" onclick="window.location='enrollment.php?view=enrolled'">Enrolled Subjects</button>
</div>

<?php if($view==='status'): ?>
<!-- SCREEN 8: Enrollment Status -->
<div class="two-col">
  <div class="card">
    <div class="card-header"><span class="card-title">Enrollment Status</span></div>
    <div class="card-body">
      <?php
      $submitted_at=$conn->query("SELECT MIN(enrolled_at) t FROM enrollments WHERE student_id=$sid AND semester_id=".($sem?$sem['semester_id']:0))->fetch_assoc()['t'];
      $approved_at=$conn->query("SELECT MIN(updated_at) t FROM enrollments WHERE student_id=$sid AND semester_id=".($sem?$sem['semester_id']:0)." AND status='approved'")->fetch_assoc()['t'];
      $confirmed_at=$conn->query("SELECT MIN(updated_at) t FROM enrollments WHERE student_id=$sid AND semester_id=".($sem?$sem['semester_id']:0)." AND status='confirmed'")->fetch_assoc()['t'];
      $statuses=array_column($subjects,'status');
      $s1=$submitted_at?'done':'number';
      $s2=in_array('approved',$statuses)||in_array('confirmed',$statuses)?'done':(in_array('pending',$statuses)?'active':'number');
      $s3=in_array('approved',$statuses)||in_array('confirmed',$statuses)?'done':'number';
      $s4=in_array('confirmed',$statuses)?'done':'number';
      ?>
      <div class="status-steps">
        <div class="status-step">
          <div class="step-circle <?= $s1 ?>"><?= $s1==='done'?'&#10003;':'1' ?></div>
          <div class="step-body"><div class="step-title">Request Submitted</div><div class="step-date"><?= $submitted_at?date('M d, Y g:i A',strtotime($submitted_at)):'Not yet submitted' ?></div></div>
        </div>
        <div class="status-step">
          <div class="step-circle <?= $s2 ?>"><?= $s2==='done'?'&#10003;':'2' ?></div>
          <div class="step-body"><div class="step-title">Under Review (Faculty)</div><div class="step-date"><?= $submitted_at?date('M d, Y g:i A',strtotime($submitted_at)):'Pending submission' ?></div></div>
        </div>
        <div class="status-step">
          <div class="step-circle <?= $s3 ?>"><?= $s3==='done'?'&#10003;':'3' ?></div>
          <div class="step-body"><div class="step-title">Approved</div><div class="step-date"><?= $approved_at?date('M d, Y g:i A',strtotime($approved_at)):'Awaiting approval' ?></div></div>
        </div>
        <div class="status-step">
          <div class="step-circle <?= $s4 === 'done' ? 'done' : 'number' ?>"><?= $s4==='done'?'&#10003;':'4' ?></div>
          <div class="step-body"><div class="step-title">Confirmed</div><div class="step-date"><?= $confirmed_at?date('M d, Y g:i A',strtotime($confirmed_at)):'Not yet confirmed' ?></div></div>
        </div>
      </div>
      <?php if($s4==='done'): ?>
      <div class="step-confirmed-box">Your enrollment has been confirmed.<br>You may now view your enrolled subjects.</div>
      <?php endif; ?>
    </div>
  </div>
  <div class="card">
    <div class="card-header"><span class="card-title">Subject Status</span></div>
    <div class="table-wrap"><table>
      <thead><tr><th>Code</th><th>Subject Title</th><th>Units</th><th>Status</th></tr></thead>
      <tbody><?php foreach($subjects as $s): ?>
      <tr><td class="td-code"><?= htmlspecialchars($s['course_code']) ?></td><td><?= htmlspecialchars($s['course_title']) ?></td><td><?= $s['units'] ?></td><td><span class="pill pill-<?= $s['status'] ?>"><?= ucfirst($s['status']) ?></span></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
  </div>
</div>

<?php elseif($view==='enrolled'): ?>
<!-- SCREEN 9: Enrolled Subjects -->
<div class="card">
  <div class="card-header">
    <span class="card-title">Enrolled Subjects</span>
    <div class="flex-center gap-2">
      <label style="font-size:12px;color:var(--text-3);">Semester:</label>
      <span class="sem-tag"><?= $sem?htmlspecialchars($sem['semester_name'].', AY '.$sem['school_year']):'—' ?></span>
    </div>
  </div>
  <?php if(empty($subjects)): ?>
  <div class="card-body"><div class="empty-state"><p>No subjects enrolled.</p></div></div>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>Code</th><th>Subject Title</th><th>Units</th><th>Status</th></tr></thead>
    <tbody><?php foreach($subjects as $s): ?>
    <tr>
      <td class="td-code"><?= htmlspecialchars($s['course_code']) ?></td>
      <td><?= htmlspecialchars($s['course_title']) ?></td>
      <td><?= $s['units'] ?></td>
      <td><?php if(in_array($s['status'],['approved','confirmed'])): ?><span class="pill pill-enrolled">Enrolled</span><?php else: ?><span class="pill pill-<?= $s['status'] ?>"><?= ucfirst($s['status']) ?></span><?php endif; ?></td>
    </tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <div class="card-footer">Total Units: <strong><?= $total_units ?></strong></div>
  <?php endif; ?>
</div>

<?php else: ?>
<!-- SCREEN 7: Submit Enrollment -->
<div class="card mb-5">
  <div class="card-header"><span class="card-title">Enrollment Summary</span></div>
  <div class="card-body" style="padding:14px 18px;">
    <div class="enroll-summary-row">
      <div class="enroll-summary-item">
        <div class="enroll-summary-label">Total Subjects</div>
        <div class="enroll-summary-value"><?= count($subjects) ?></div>
      </div>
      <div class="enroll-summary-item">
        <div class="enroll-summary-label">Total Units</div>
        <div class="enroll-summary-value"><?= $total_units ?></div>
      </div>
      <div class="enroll-summary-item">
        <div class="enroll-summary-label">Status</div>
        <div class="enroll-summary-value pending"><?= $has_pending?'Pending':($all_approved?'Approved':'—') ?></div>
      </div>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header"><span class="card-title">Subjects to be Enrolled</span></div>
  <?php if(empty($subjects)): ?>
  <div class="card-body"><div class="empty-state"><p>No subjects added yet.</p><a href="add_subject.php" class="btn btn-brown btn-sm mt-3">Add Subject</a></div></div>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>Code</th><th>Subject Title</th><th>Units</th><th>Status</th></tr></thead>
    <tbody><?php foreach($subjects as $s): ?>
    <tr>
      <td class="td-code"><?= htmlspecialchars($s['course_code']) ?></td>
      <td><?= htmlspecialchars($s['course_title']) ?></td>
      <td><?= $s['units'] ?></td>
      <td><span class="pill pill-<?= $s['status'] ?>"><?= ucfirst($s['status']) ?></span></td>
    </tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <?php if($has_pending && $eo): ?>
  <div class="card-body" style="padding-top:0;">
    <form method="POST" style="margin-top:12px;">
      <button type="submit" name="submit_enrollment" class="btn-submit-enroll" onclick="return confirm('Submit enrollment for faculty verification?')">Submit Enrollment</button>
    </form>
  </div>
  <?php elseif(!$eo): ?>
  <div class="card-footer"><span style="color:var(--text-3);font-size:13px;">Enrollment period is closed.</span></div>
  <?php else: ?>
  <div class="card-footer"><span style="color:var(--green);font-size:13px;">All subjects already submitted or approved.</span></div>
  <?php endif; ?>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
