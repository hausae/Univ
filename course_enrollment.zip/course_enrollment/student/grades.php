<?php
define('IN_SUBFOLDER',true); session_start();
require_once '../includes/db.php'; require_once '../includes/auth.php';
require_login('student');
$sid=$_SESSION['user_id'];
$sem_filter=(int)($_GET['semester_id']??0);
$sems=$conn->query("SELECT DISTINCT s.* FROM semesters s JOIN enrollments e ON e.semester_id=s.semester_id JOIN grades g ON g.enrollment_id=e.enrollment_id WHERE e.student_id=$sid ORDER BY s.start_date DESC");
$sem_list=[]; while($r=$sems->fetch_assoc()) $sem_list[]=$r;
if(!$sem_filter && !empty($sem_list)) $sem_filter=$sem_list[0]['semester_id'];
$where="e.student_id=$sid"; if($sem_filter) $where.=" AND e.semester_id=$sem_filter";
$rows=[]; $tu=0; $tw=0;
$r=$conn->query("SELECT g.grade,g.remarks,c.course_code,c.course_title,c.units,s2.semester_name,s2.school_year FROM grades g JOIN enrollments e ON e.enrollment_id=g.enrollment_id JOIN courses c ON c.course_id=e.course_id JOIN semesters s2 ON s2.semester_id=e.semester_id WHERE $where ORDER BY c.course_code");
while($row=$r->fetch_assoc()){$rows[]=$row;if($row['grade']!==null&&$row['grade']<=3.0){$tu+=$row['units'];$tw+=$row['grade']*$row['units'];}}
$gpa=$tu>0?$tw/$tu:null;
$page_title='View Grades'; $active_nav='grades'; include '../includes/header.php';
?>
<div class="card">
  <div class="card-header">
    <span class="card-title">View Grades</span>
    <div style="display:flex;align-items:center;gap:8px;">
      <label class="form-label" style="margin:0;white-space:nowrap;font-size:12px;">Semester:</label>
      <select class="form-control" style="width:auto;font-size:12.5px;" onchange="location='?semester_id='+this.value">
        <?php foreach($sem_list as $s): ?>
        <option value="<?= $s['semester_id'] ?>" <?= $sem_filter==$s['semester_id']?'selected':'' ?>><?= htmlspecialchars($s['semester_name'].', AY '.$s['school_year']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>
  <?php if(empty($rows)): ?>
  <div class="card-body"><div class="empty-state"><p>No grades posted yet.</p></div></div>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>Code</th><th>Subject Title</th><th>Units</th><th>Grade</th></tr></thead>
    <tbody>
      <?php foreach($rows as $g): $gv=$g['grade']!==null?(float)$g['grade']:null; ?>
      <tr>
        <td class="td-code"><?= htmlspecialchars($g['course_code']) ?></td>
        <td><?= htmlspecialchars($g['course_title']) ?></td>
        <td><?= $g['units'] ?></td>
        <td><?php if($g['remarks']==='INC'): ?><span class="grade-val inc">INC</span>
            <?php elseif($gv!==null): ?><span class="grade-val <?= $gv<=3.0?'pass':'fail' ?>"><?= number_format($gv,2) ?></span>
            <?php else: ?>—<?php endif; ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table></div>
  <div class="card-footer">
    <strong>GPA (Semester): <?= $gpa!==null?number_format($gpa,2):'—' ?></strong>
  </div>
  <?php endif; ?>
</div>
<?php include '../includes/footer.php'; ?>
