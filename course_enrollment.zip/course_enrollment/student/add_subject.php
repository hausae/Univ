<?php
define('IN_SUBFOLDER',true); session_start();
require_once '../includes/db.php'; require_once '../includes/auth.php';
require_login('student');
$sid=$_SESSION['user_id']; $sem=active_semester($conn);
$eo=enrollment_open($conn);

// Handle enroll POST
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['enroll_course_id'])){
    $cid=(int)$_POST['enroll_course_id'];
    if(!$sem||!$eo){flash('error','Enrollment period is closed.');header('Location: add_subject.php');exit;}
    $chk=$conn->query("SELECT enrollment_id FROM enrollments WHERE student_id=$sid AND course_id=$cid AND semester_id={$sem['semester_id']}")->fetch_assoc();
    if($chk){flash('error','Already enrolled or pending for this subject.');header('Location: add_subject.php');exit;}
    $pq=check_prerequisites($conn,$cid,$sid);
    if(!$pq['met']){flash('error','You have unmet prerequisites.');header('Location: add_subject.php?course_id='.$cid);exit;}
    $cap=$conn->query("SELECT capacity FROM courses WHERE course_id=$cid")->fetch_assoc()['capacity'];
    if(enrolled_count($conn,$cid,$sem['semester_id'])>=$cap){flash('error','Subject is full.');header('Location: add_subject.php');exit;}
    $stmt=$conn->prepare("INSERT INTO enrollments (student_id,course_id,semester_id,status) VALUES (?,?,?,'pending')");
    $stmt->bind_param('iii',$sid,$cid,$sem['semester_id']);$stmt->execute();$stmt->close();
    $fac=$conn->query("SELECT faculty_id FROM courses WHERE course_id=$cid")->fetch_assoc();
    $ci=$conn->query("SELECT course_code,course_title FROM courses WHERE course_id=$cid")->fetch_assoc();
    if($fac) add_notification($conn,'faculty',$fac['faculty_id'],"{$_SESSION['user_name']} enrolled in {$ci['course_code']}.");
    add_notification($conn,'student',$sid,"Enrollment request for {$ci['course_code']} submitted.");
    flash('success','Subject added! Awaiting faculty verification.');
    header('Location: add_subject.php');exit;
}

// Selected course preview
$sel_cid=(int)($_GET['course_id']??0);
$sel_course=null; $pq_result=null;
if($sel_cid && $sem){
    $sel_course=$conn->query("SELECT c.*,f.full_name AS faculty_name FROM courses c LEFT JOIN faculty f ON f.faculty_id=c.faculty_id WHERE c.course_id=$sel_cid AND c.semester_id={$sem['semester_id']}")->fetch_assoc();
    if($sel_course) $pq_result=check_prerequisites($conn,$sel_cid,$sid);
}

// Available courses (not yet enrolled)
$available=[];
if($sem){
    $r=$conn->query("SELECT c.*,(SELECT COUNT(*) FROM enrollments e2 WHERE e2.course_id=c.course_id AND e2.semester_id=c.semester_id AND e2.status NOT IN ('dropped','rejected')) AS enrolled_count,(SELECT e3.status FROM enrollments e3 WHERE e3.student_id=$sid AND e3.course_id=c.course_id AND e3.semester_id=c.semester_id LIMIT 1) AS my_status FROM courses c WHERE c.semester_id={$sem['semester_id']} ORDER BY c.course_code");
    while($row=$r->fetch_assoc()){$pq=check_prerequisites($conn,(int)$row['course_id'],$sid);$row['prereq_met']=$pq['met'];$row['slots_left']=max(0,$row['capacity']-$row['enrolled_count']);$available[]=$row;}
}
$page_title='Add Subject'; $active_nav='add_sub'; include '../includes/header.php';
?>
<div style="font-size:12.5px;color:var(--text-3);margin-bottom:10px;">
  Current Semester: <strong><?= $sem?htmlspecialchars($sem['semester_name'].', AY '.$sem['school_year']):'None' ?></strong>
</div>

<?php if(!$eo): ?><div class="period-banner closed">Enrollment period is closed. You cannot add subjects at this time.</div><?php endif; ?>

<div class="sidebar-layout">
  <!-- Subject selector -->
  <div class="card">
    <div class="card-header"><span class="card-title">Select Subject</span></div>
    <div class="card-body">
      <div class="form-group">
        <label class="form-label">Available Subjects</label>
        <select class="form-control" id="subjectSelect" onchange="previewSubject(this.value)">
          <option value="">— Choose a subject —</option>
          <?php foreach($available as $c): ?>
          <option value="<?= $c['course_id'] ?>" <?= $sel_cid==$c['course_id']?'selected':'' ?>
            <?= ($c['my_status']||!$c['prereq_met']||$c['slots_left']<=0)?'data-disabled=1':'' ?>>
            <?= htmlspecialchars($c['course_code'].' — '.$c['course_title'].' ('.$c['units'].' units)') ?>
            <?= $c['my_status']?' ['.ucfirst($c['my_status']).']':(!$c['prereq_met']?' [Prereq missing]':($c['slots_left']<=0?' [Full]':'')) ?>
          </option>
          <?php endforeach; ?>
        </select>
      </div>

      <?php if($sel_course && $pq_result): ?>
      <!-- Prerequisite check panel -->
      <div class="prereq-box">
        <div style="font-weight:700;font-size:13px;margin-bottom:8px;"><?= htmlspecialchars($sel_course['course_code']) ?> — <?= htmlspecialchars($sel_course['course_title']) ?> (<?= $sel_course['units'] ?> units)</div>
        <?php if(!empty($pq_result['prereqs'])): ?>
          <?php foreach($pq_result['prereqs'] as $p): ?>
          <div class="prereq-row">
            <span class="<?= $p['passed']?'prereq-check':'prereq-cross' ?>"><?= $p['passed']?'&#10003;':'&#10007;' ?></span>
            <span>Prerequisite: <strong><?= htmlspecialchars($p['course_code']) ?> — <?= htmlspecialchars($p['course_title']) ?></strong></span>
          </div>
          <?php endforeach; ?>
        <?php else: ?>
        <div class="prereq-row"><span class="prereq-check">&#10003;</span><span>No prerequisites required</span></div>
        <?php endif; ?>
        <?php $slots=max(0,$sel_course['capacity']-enrolled_count($conn,$sel_cid,$sem['semester_id'])); ?>
        <div class="prereq-row" style="margin-top:6px;">
          <span class="<?= $slots>0?'prereq-check':'prereq-cross' ?>"><?= $slots>0?'&#10003;':'&#10007;' ?></span>
          <span>Available: <?= $sem?htmlspecialchars($sem['semester_name']):'—' ?> &nbsp;|&nbsp; Slots left: <?= $slots ?></span>
        </div>
        <div class="prereq-row">
          <span class="<?= $pq_result['met']&&$slots>0?'prereq-check':'prereq-cross' ?>"><?= $pq_result['met']&&$slots>0?'&#10003;':'&#10007;' ?></span>
          <span>Status: <strong><?= $pq_result['met']&&$slots>0?'Prerequisite will be available this semester':'Prerequisites not met or subject full' ?></strong></span>
        </div>
      </div>

      <?php
      $already=$conn->query("SELECT status FROM enrollments WHERE student_id=$sid AND course_id=$sel_cid AND semester_id={$sem['semester_id']}")->fetch_assoc();
      if($already): ?>
      <div style="margin-top:12px;"><span class="pill pill-<?= $already['status'] ?>">Already <?= ucfirst($already['status']) ?></span></div>
      <?php elseif($eo && $pq_result['met'] && $slots>0): ?>
      <form method="POST" style="margin-top:12px;">
        <input type="hidden" name="enroll_course_id" value="<?= $sel_cid ?>">
        <button type="submit" class="btn btn-brown btn-block" onclick="return confirm('Add <?= htmlspecialchars(addslashes($sel_course['course_code'])) ?>?')">Add Subject</button>
      </form>
      <?php elseif(!$pq_result['met']): ?>
      <button class="btn btn-ghost btn-block" style="margin-top:12px;" disabled>Prerequisites Not Met</button>
      <?php elseif($slots<=0): ?>
      <button class="btn btn-ghost btn-block" style="margin-top:12px;" disabled>Subject Full</button>
      <?php endif; ?>
      <?php endif; ?>
    </div>
  </div>

  <!-- Available table -->
  <div class="card">
    <div class="card-header"><span class="card-title">Subject List</span></div>
    <div class="table-wrap"><table>
      <thead><tr><th>Code</th><th>Subject Title</th><th>Units</th><th>Slots</th><th>Status</th></tr></thead>
      <tbody><?php foreach($available as $c): ?>
      <tr style="cursor:pointer;" onclick="selectAndPreview(<?= $c['course_id'] ?>)">
        <td class="td-code"><?= htmlspecialchars($c['course_code']) ?></td>
        <td><?= htmlspecialchars($c['course_title']) ?></td>
        <td><?= $c['units'] ?></td>
        <td style="font-size:12px;"><?= $c['slots_left'] ?> / <?= $c['capacity'] ?></td>
        <td>
          <?php if($c['my_status']): ?><span class="pill pill-<?= $c['my_status'] ?>"><?= ucfirst($c['my_status']) ?></span>
          <?php elseif(!$c['prereq_met']): ?><span class="pill pill-locked">Locked</span>
          <?php elseif($c['slots_left']<=0): ?><span class="pill pill-full">Full</span>
          <?php else: ?><span class="pill pill-available">Available</span><?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?></tbody>
    </table></div>
  </div>
</div>

<script>
function previewSubject(id){if(id) window.location='add_subject.php?course_id='+id;}
function selectAndPreview(id){window.location='add_subject.php?course_id='+id;}
document.getElementById('subjectSelect').addEventListener('change',function(){previewSubject(this.value);});
</script>
<?php include '../includes/footer.php'; ?>
